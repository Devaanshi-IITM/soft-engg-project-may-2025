import SeniorLogin from './pages/SeniorLogin.js';
import GuardianAuth from './pages/GuardianAuth.js';
import SeniorDashboard from './pages/SeniorDashboard.js';
import GuardianDashboard from './pages/GuardianDashboard.js';
import SeniorProfileView from './pages/SeniorProfileView.js';
import SeniorRegister from './pages/SeniorRegister.js';
import ManageReminders from './pages/ManageReminders.js';
import ManageAppointments from './pages/ManageAppointments.js';
import GuardianMessages from './pages/GuardianMessages.js';
import GuardianUploadAudio from './pages/GuardianUploadAudio.js';
import SeniorAudioGallery from './pages/SeniorAudioGallery.js';
import SeniorGames from './pages/SeniorGames.js'; // <-- new import

const routes = [
  { path: '/', component: SeniorLogin },
  { path: '/guardian/login', component: GuardianAuth },
  { path: '/senior/dashboard', component: SeniorDashboard },
  { path: '/guardian/dashboard', component: GuardianDashboard },
  { path: '/senior/profile', component: SeniorProfileView },
  { path: '/senior/audios', component: SeniorAudioGallery }, 
  { path: '/senior/games', component: SeniorGames }, // <-- new route
  { path: '/guardian/register-senior', component: SeniorRegister },
  { path: '/guardian/manage-reminders', component: ManageReminders },
  { path: '/guardian/manage-appointments', component: ManageAppointments },
  { path: '/guardian/senior/:seniorId/messages', component: GuardianMessages },
  { path: '/guardian/senior/:seniorId/upload', component: GuardianUploadAudio },
  { path: '*', component: { template: '<div class="p-4 text-center"><h2>Page not found</h2></div>' } },
];

const router = new VueRouter({
  routes
});

export default router;
