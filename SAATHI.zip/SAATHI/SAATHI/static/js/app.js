import Vue from 'https://cdn.jsdelivr.net/npm/vue@2.7.16/dist/vue.esm.browser.js';
import router from './router.js';


Vue.use(VueRouter);

new Vue({
  el: '#app',
  router
});