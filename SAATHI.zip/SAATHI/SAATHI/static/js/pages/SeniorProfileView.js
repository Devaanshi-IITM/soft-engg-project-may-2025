export default {
  template: `
    <div class="user-profile container-fluid py-4">
      <div class="glass-card p-4 shadow-lg rounded-4">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-5 flex-wrap border-bottom pb-3">
          <div>
            <h1 class="fw-bold text-dark mb-1">👤 Profile</h1>
            <p class="lead text-muted mb-0">Your personal details at a glance</p>
          </div>
          <button class="btn btn-outline-danger px-4 py-2 rounded-pill fw-semibold" @click="logout">
            <i class="fas fa-sign-out-alt me-2"></i>Logout
          </button>
        </div>

        <!-- Profile Details -->
        <section>
          <h3 class="mb-4 text-primary fw-bold">
            <i class="fas fa-id-card me-2"></i>Account Information
          </h3>

          <div class="row g-4">
            <!-- Left column -->
            <div class="col-md-6">
              <div class="card shadow-sm rounded-3 border-0 h-100">
                <div class="card-body">
                  <h5 class="card-title text-secondary mb-4">👨 Senior Details</h5>

                  <div class="mb-3">
                    <label class="form-label fw-bold text-muted">Full Name</label>
                    <div class="p-2 rounded bg-light fw-semibold text-dark">
                      {{ user.name || 'Not Provided' }}
                    </div>
                  </div>

                  <div>
                    <label class="form-label fw-bold text-muted">Phone</label>
                    <div class="p-2 rounded bg-light fw-semibold text-dark">
                      {{ user.phone || 'Not Provided' }}
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Right column -->
            <div class="col-md-6">
              <div class="card shadow-sm rounded-3 border-0 h-100">
                <div class="card-body">
                  <h5 class="card-title text-secondary mb-4">👨 Guardian Details</h5>

                  <div class="mb-3">
                    <label class="form-label fw-bold text-muted">Guardian Name</label>
                    <div class="p-2 rounded bg-light fw-semibold text-dark">
                      {{ user.guardian?.name || 'Not Linked' }}
                    </div>
                  </div>

                  <div>
                    <label class="form-label fw-bold text-muted">Guardian Phone</label>
                    <div class="p-2 rounded bg-light fw-semibold text-dark">
                      {{ user.guardian?.phone || 'Not Provided' }}
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- Action Buttons -->
        <div class="mt-5 text-end">
          <button class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold" @click="goBack">
            <i class="fas fa-arrow-left me-2"></i>Back
          </button>
        </div>

      </div>
    </div>
  `,

  data() {
    return {
      user: {
        id: null,
        name: '',
        phone: '',
        guardian: {
          id: null,
          name: '',
          phone: ''
        }
      }
    };
  },

methods: {
    loadData() {
      const id = localStorage.getItem('senior_id');
      if (!id) {
        alert("Not logged in.");
        this.$router.push('/');
        return;
      }

      fetch(`/senior/${id}/profile`)
        .then(res => res.json())
        .then(data => {
          this.user = data.user;
        });
    },

    goBack() {
      this.$router.push('/senior/dashboard');
    },

    logout() {
      localStorage.removeItem('senior_id');
      this.$router.push('/');
    }
  },

  mounted() {
    this.loadData();
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  }
};
