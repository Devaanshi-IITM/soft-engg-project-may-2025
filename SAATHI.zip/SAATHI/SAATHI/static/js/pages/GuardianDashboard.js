const GuardianDashboard = {
  template: `
    <div class="container-fluid py-4">
      <div class="glass-card p-4 shadow-lg rounded-4">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-5 flex-wrap border-bottom pb-3">
          <div>
            <h1 class="fw-bold text-dark mb-1">Guardian Dashboard</h1>
            <p class="lead text-muted mb-0">Manage seniors, reminders, and appointments</p>
          </div>
          <button class="btn btn-outline-danger px-4 py-2 rounded-pill fw-semibold" @click="logout">
            <i class="fas fa-sign-out-alt me-2"></i>Logout
          </button>
        </div>

        <!-- Add Senior Button -->
        <div class="mb-5 text-end">
          <button class="btn btn-primary px-4 py-2 rounded-pill fw-semibold" @click="goToSeniorRegister">
            <i class="fas fa-user-plus me-2"></i>Register a Senior
          </button>
        </div>

        <!-- Quick Actions -->
        <section v-if="seniors.length > 0" class="mb-5">
          <h3 class="mb-4 text-primary fw-bold">
            <i class="fas fa-bolt me-2"></i>Quick Actions
          </h3>
          <div class="row g-4">
            <div class="col-md-3">
              <div class="card shadow-sm rounded-3 border-0 cursor-pointer h-100" @click="goToUpload">
                <div class="card-body text-center">
                  <div class="display-4">🧾</div>
                  <h5 class="mt-3 fw-semibold text-dark">Upload Content</h5>
                  <p class="text-muted small mb-0">Share helpful information with seniors</p>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card shadow-sm rounded-3 border-0 cursor-pointer h-100" @click="goToMessages">
                <div class="card-body text-center">
                  <div class="display-4">💬</div>
                  <h5 class="mt-3 fw-semibold text-dark">Messages</h5>
                  <p class="text-muted small mb-0">Communicate with your seniors</p>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card shadow-sm rounded-3 border-0 cursor-pointer h-100" @click="goToReminders">
                <div class="card-body text-center">
                  <div class="display-4">💊</div>
                  <h5 class="mt-3 fw-semibold text-dark">Manage Reminders</h5>
                  <p class="text-muted small mb-0">Create, update, or delete reminders for seniors</p>
                </div>
              </div>
            </div>
            <div class="col-md-3">
              <div class="card shadow-sm rounded-3 border-0 cursor-pointer h-100" @click="goToAppointments">
                <div class="card-body text-center">
                  <div class="display-4">📅</div>
                  <h5 class="mt-3 fw-semibold text-dark">Appointments</h5>
                  <p class="text-muted small mb-0">Schedule and manage senior appointments</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <!-- Seniors Section -->
        <section v-if="seniors.length > 0">
          <h3 class="mb-4 text-primary fw-bold">
            <i class="fas fa-users me-2"></i>My Seniors
          </h3>

          <div class="row g-4">
            <div v-for="senior in seniors" :key="senior.id" class="col-md-6">
              <div class="card shadow-sm rounded-3 border-0 h-100">
                <div class="card-body">
                  <h5 class="card-title fw-bold text-dark mb-1">{{ senior.name }}</h5>
                  <p class="text-muted small mb-3">📞 {{ senior.phone }}</p>
                </div>
              </div>
            </div>
          </div>
        </section>

        <div v-if="seniors.length === 0" class="text-center text-muted my-5">
          <p class="mb-3">You haven’t added any seniors yet.</p>
        </div>

      </div>
    </div>
  `,

  data() {
    return {
      guardianId: localStorage.getItem('guardian_id') || null,
      seniors: []
    };
  },

  mounted() {
    if (!this.guardianId) {
      alert("Please log in first.");
      this.$router.push('/guardian/login');
      return;
    }
    this.fetchSeniors();
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  },

  methods: {
    async fetchSeniors() {
      try {
        const res = await fetch(`/guardian/${this.guardianId}/seniors`);
        const data = await res.json();

        this.seniors = await Promise.all(
          data.seniors.map(async s => {
            const res = await fetch(`/senior/${s.id}/dashboard`);
            const dashboard = await res.json();

            const pendingReminders = (dashboard.reminders || []).filter(r => !r.completed);
            const pendingAppointments = (dashboard.appointments || []).filter(a => !a.completed);

            return {
              id: s.id,
              name: s.name,
              phone: s.phone,
              pendingReminders,
              pendingAppointments
            };
          })
        );
      } catch (err) {
        console.error("Error loading seniors:", err);
        alert("Failed to load senior data.");
      }
    },

    logout() {
      localStorage.removeItem('guardian_id');
      this.$router.push('/guardian/login');
    },

    goToSeniorRegister() {
      this.$router.push('/guardian/register-senior');
    },

    goToUpload() {
      if (this.seniors.length > 0) {
        this.$router.push(`/guardian/senior/${this.seniors[0].id}/upload`);
      }
    },

    goToMessages() {
      if (this.seniors.length > 0) {
        this.$router.push(`/guardian/senior/${this.seniors[0].id}/messages`);
      }
    },

    goToSeniorMessages(seniorId) {
      this.$router.push(`/guardian/senior/${seniorId}/messages`);
    },

    goToReminders(seniorId = null) {
      if (seniorId) {
        this.$router.push(`/guardian/manage-reminders?senior_id=${seniorId}`);
      } else {
        this.$router.push('/guardian/manage-reminders');
      }
    },

    goToAppointments(seniorId = null) {
      if (seniorId) {
        this.$router.push(`/guardian/manage-appointments?senior_id=${seniorId}`);
      } else {
        this.$router.push('/guardian/manage-appointments');
      }
    }
  }
};

export default GuardianDashboard;
