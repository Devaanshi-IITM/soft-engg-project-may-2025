
export default {
    template: `
      <div class="landing-container">
        <div class="landing-header">
          <h1>Saathi</h1>
          <p>Your Digital Companion</p>
        </div>
  
        <div v-if="!otpSent">
          <label class="form-label">Enter Your Phone Number</label>
          <input v-model="phone" class="form-control mb-3" placeholder="e.g. 9876543210">
          <button class="btn btn-primary w-100" @click="sendOTP">
            <i class="fas fa-sms me-1"></i> Send OTP
          </button>
        </div>
  
        <div v-else>
          <label class="form-label">Enter OTP</label>
          <input v-model="otp" class="form-control mb-3" placeholder="Enter the 6-digit OTP">
          <button class="btn btn-primary w-100" @click="verifyOTP">
            <i class="fas fa-unlock me-1"></i> Verify & Login
          </button>
        </div>
  
        <hr class="my-4">
        <div class="text-center">
          <p class="mb-0">Are you a Guardian?</p>
          <router-link to="/guardian/login" class="link-secondary">Go to Guardian Login/Register</router-link>
        </div>
      </div>
    `,
    
    data() {
      return {
        phone: '',
        otp: '',
        otpSent: false
      };
    },
  
    mounted() {
      document.body.style.background = 'linear-gradient(to right, #FFEFBA, #FDB813)';
    },
  
    beforeDestroy() {
      document.body.style.background = '';
    },
  
    methods: {
      sendOTP() {
        if (!this.phone) return alert("Please enter your phone number.");
        fetch('/senior/send_otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone: this.phone })
        })
        .then(res => res.json())
        .then(data => {
          if (data.message) {
            alert("OTP sent to your number.");
            this.otpSent = true;
          } else {
            alert(data.error || "Something went wrong.");
          }
        });
      },
  
      verifyOTP() {
        if (!this.otp) return alert("Please enter the OTP.");
        fetch('/senior/verify_otp', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ phone: this.phone, otp: this.otp })
        })
        .then(res => res.json())
        .then(data => {
          if (data.senior_id) {
            alert("Welcome " + data.name + "!");
            localStorage.setItem('senior_id', data.senior_id);
            this.$router.push('/senior/dashboard');
          } else {
            alert(data.error || "Invalid OTP.");
          }
        });
      }
    }
  };