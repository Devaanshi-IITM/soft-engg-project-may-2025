const GuardianUploadAudio = {
  template: `
    <div class="guardian-upload-audio container-fluid py-4">

      <!-- Header -->
      <div class="glass-card p-4 shadow-lg mb-4 d-flex justify-content-between align-items-center">
        <h1 class="fw-bold text-dark">🎵 Audio Sharing</h1>
        <button class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold" @click="goBack">
            <i class="fas fa-arrow-left me-2"></i>Back
        </button>
      </div>

      <!-- Upload Card -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h4 class="fw-bold text-primary mb-3">
          <i class="fas fa-upload me-2"></i>Upload New Audio
        </h4>

        <form @submit.prevent="uploadAudio" enctype="multipart/form-data">

          <!-- Senior Selection -->
          <div class="mb-3">
            <label class="form-label fw-semibold">Select Senior(s)</label>
            <div class="d-flex flex-wrap gap-2">
              <div v-for="s in seniors" :key="s.id" class="form-check form-check-inline">
                <input class="btn-check" type="checkbox" :id="'senior-' + s.id"
                       :value="s.id" v-model="selectedSeniorIds">
                <label class="btn btn-outline-primary rounded-pill px-3 py-1" :for="'senior-' + s.id">
                  {{ s.name }}
                </label>
              </div>
            </div>
            <small class="text-muted">Click to toggle multiple seniors</small>
          </div>

          <!-- Title -->
          <div class="mb-3">
            <label class="form-label fw-semibold">Audio Title</label>
            <input type="text" v-model="title" class="form-control" placeholder="Enter a title" required />
          </div>

          <!-- File -->
          <div class="mb-4">
            <label class="form-label fw-semibold">Select Audio File</label>
            <input type="file" ref="fileInput" @change="handleFileUpload" class="form-control" accept="audio/*" required />
          </div>

          <!-- Submit -->
          <div class="text-end">
            <button type="submit" class="btn btn-primary px-4">
              <i class="fas fa-upload me-2"></i>Upload
            </button>
          </div>
        </form>
      </div>

      <!-- Uploaded Audios Card -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h4 class="fw-bold text-primary mb-3">
          <i class="fas fa-music me-2"></i>Uploaded Audios
        </h4>

        <!-- Search -->
        <div class="mb-3">
          <input type="text" v-model="searchQuery" class="form-control" placeholder="Search by senior or title...">
        </div>

        <div v-if="filteredAudios.length > 0" class="list-group">
          <div v-for="a in filteredAudios" :key="a.id"
               class="list-group-item d-flex justify-content-between align-items-center flex-wrap">

            <div class="me-3">
              <strong>{{ a.title }}</strong>
              <br/>
              <small class="text-muted">For: {{ getSeniorName(a.senior_id) }}</small>
            </div>

            <!-- Audio Actions -->
            <div class="d-flex align-items-center gap-3 flex-wrap audio-actions">

              <!-- Player -->
              <audio 
                ref="audioPlayers" 
                :data-id="a.id" 
                :src="a.stream_url" 
                controls 
                @play="handlePlay(a.id)" 
                style="max-width: 500px;">
              </audio>

              <!-- Speed Control -->
              <select 
                class="form-select form-select-sm" 
                style="width:90px; height:38px;" 
                v-model="playbackRates[a.id]" 
                @change="changePlaybackRate(a.id)">
                <option :value="1">1x</option>
                <option :value="1.25">1.25x</option>
                <option :value="1.5">1.5x</option>
                <option :value="2">2x</option>
              </select>

              <!-- Vertical Button Group -->
              <div class="d-flex flex-column gap-2">
                <a :href="a.download_url" class="btn btn-outline-success d-flex align-items-center gap-1">
                  <i class="fas fa-download"></i> <span>Download</span>
                </a>
                <button class="btn btn-outline-danger d-flex align-items-center gap-1" @click="deleteAudio(a.id)">
                  <i class="fas fa-trash"></i> <span>Delete</span>
                </button>
              </div>

            </div>
          </div>
        </div>

        <p v-else class="text-muted">No audios uploaded yet.</p>
      </div>

    </div>
  `,

  data() {
    return {
      guardianId: localStorage.getItem('guardian_id') || null,
      seniors: [],
      selectedSeniorIds: [],
      title: "",
      file: null,
      audios: [],
      searchQuery: "",
      playbackRates: {}
    };
  },

  computed: {
    filteredAudios() {
      const q = this.searchQuery.toLowerCase();
      return this.audios.filter(a => {
        const seniorName = this.getSeniorName(a.senior_id).toLowerCase();
        return a.title.toLowerCase().includes(q) || seniorName.includes(q);
      });
    }
  },

  mounted() {
    if (!this.guardianId) {
      alert("Please log in first.");
      this.$router.push('/guardian/login');
      return;
    }
    this.fetchSeniors();
    this.fetchAudios();
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  },

  methods: {
    async fetchSeniors() {
      try {
        const res = await fetch(`/guardian/${this.guardianId}/seniors`);
        const data = await res.json();
        this.seniors = data.seniors || [];
      } catch (err) {
        console.error("Error fetching seniors:", err);
      }
    },

    async fetchAudios() {
      try {
        const res = await fetch(`/guardian/${this.guardianId}/audios`);
        const data = await res.json();
        this.audios = (data.audios || []).map(a => ({
          ...a,
          stream_url: `/guardian/${this.guardianId}/audios/${a.id}/stream`,
          download_url: `/guardian/${this.guardianId}/audios/${a.id}/download`
        }));
        this.audios.forEach(a => this.$set(this.playbackRates, a.id, 1));
      } catch (err) {
        console.error("Error fetching audios:", err);
      }
    },

    handleFileUpload(event) {
      this.file = event.target.files[0];
    },

    async uploadAudio() {
      if (!this.selectedSeniorIds.length || !this.title || !this.file) {
        alert("Please fill all fields and select a file.");
        return;
      }

      try {
        const formData = new FormData();
        formData.append("senior_ids", JSON.stringify(this.selectedSeniorIds));
        formData.append("title", this.title);
        formData.append("file", this.file);

        const res = await fetch(`/guardian/${this.guardianId}/upload-audio`, {
          method: "POST",
          body: formData
        });

        const data = await res.json();

        if (!res.ok) {
          throw new Error(data.error || "Upload failed");
        }

        alert("Audio uploaded successfully!");
        this.title = "";
        this.file = null;
        this.selectedSeniorIds = [];
        this.$refs.fileInput.value = "";
        this.fetchAudios();
      } catch (err) {
        console.error("Error uploading audio:", err);
        alert("Upload failed: " + err.message);
      }
    },

    async deleteAudio(audioId) {
      if (!confirm("Are you sure you want to delete this audio?")) return;
      try {
        const res = await fetch(`/guardian/${this.guardianId}/audios/${audioId}`, {
          method: "DELETE"
        });
        if (res.ok) {
          this.audios = this.audios.filter(a => a.id !== audioId);
          alert("Audio deleted successfully.");
        } else {
          alert("Failed to delete audio.");
        }
      } catch (err) {
        console.error("Error deleting audio:", err);
      }
    },

    handlePlay(audioId) {
      this.$refs.audioPlayers.forEach(player => {
        if (player.dataset.id != audioId) {
          player.pause();
        }
      });
    },

    changePlaybackRate(audioId) {
      const player = this.$refs.audioPlayers.find(p => p.dataset.id == audioId);
      if (player) {
        player.playbackRate = this.playbackRates[audioId];
      }
    },

    getSeniorName(seniorId) {
      const s = this.seniors.find(x => x.id === seniorId);
      return s ? s.name : "Unknown";
    },
    goBack() {
      this.$router.push('/guardian/dashboard');
    }
  }
};

export default GuardianUploadAudio;
