export default {
  template: `
    <div class="senior-dashboard container-fluid py-4">

      <!-- Header Card -->
      <div class="glass-card p-4 shadow-lg mb-4 d-flex justify-content-between align-items-center flex-wrap">
        <h1 class="fw-bold text-dark mb-0">Entertainment</h1>
        <button class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold" @click="goBack">
            <i class="fas fa-arrow-left me-2"></i>Back
          </button>
      </div>

      <!-- Search Card -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <input 
          type="text" 
          v-model="searchQuery" 
          class="form-control form-control-lg" 
          placeholder="Search your audio..."
        >
      </div>

      <!-- Audio Library Card -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h4 class="mb-3 text-primary"><i class="fas fa-music me-2"></i>Audio Library</h4>
        <div v-if="filteredAudio.length === 0" class="text-muted">No audio found.</div>
        <ul class="list-group">
          <li 
            v-for="(audio, index) in filteredAudio" 
            :key="audio.id" 
            class="list-group-item d-flex justify-content-between align-items-center clickable"
            :class="{ 'active-audio': currentAudioIndex === index }"
            @click="playAudio(index)"
          >
            <span>{{ audio.title }}</span>
            <span v-if="currentAudioIndex === index && isPlaying">
              <i class="fas fa-volume-up text-success"></i>
            </span>
          </li>
        </ul>
      </div>

      <!-- Audio Player Card -->
      <div v-if="currentAudioIndex !== null" class="glass-card p-4 shadow-lg mb-4">
        <h5 class="mb-3">{{ currentAudio.title }}</h5>
        <audio ref="audioPlayer" :src="audioPath(currentAudio.filename)" @ended="nextAudio"></audio>

        <div class="d-flex align-items-center gap-3">
          <button class="btn btn-outline-primary" @click="prevAudio">
            <i class="fas fa-backward"></i>
          </button>
          <button class="btn btn-outline-primary" @click="togglePlay">
            <i :class="isPlaying ? 'fas fa-pause' : 'fas fa-play'"></i>
          </button>
          <button class="btn btn-outline-primary" @click="nextAudio">
            <i class="fas fa-forward"></i>
          </button>

          <div class="ms-auto d-flex align-items-center gap-2">
            <label class="mb-0">Speed:</label>
            <select v-model="playbackRate" @change="changeSpeed" class="form-select form-select-sm">
              <option v-for="s in speeds" :value="s">{{ s }}x</option>
            </select>
          </div>
        </div>

        <!-- Clickable/Scrollable Progress Bar -->
        <div 
          class="progress mt-3" 
          style="height: 8px; cursor: pointer;" 
          @click="seekAudio($event)"
        >
          <div 
            class="progress-bar bg-success" 
            :style="{ width: progress + '%' }"
          ></div>
        </div>
      </div>

    </div>
  `,

  data() {
    return {
      audioList: [],
      searchQuery: '',
      currentAudioIndex: null,
      isPlaying: false,
      playbackRate: 1,
      speeds: [0.5, 1, 1.25, 1.5, 2],
      progress: 0
    };
  },

  computed: {
    filteredAudio() {
      const q = this.searchQuery.toLowerCase();
      return this.audioList.filter(a => a.title.toLowerCase().includes(q));
    },
    currentAudio() {
      return this.audioList[this.currentAudioIndex] || {};
    }
  },

  methods: {
    loadAudio() {
      const seniorId = localStorage.getItem('senior_id');
      if (!seniorId) {
        alert("Not logged in.");
        this.$router.push('/');
        return;
      }

      fetch(`/senior/${seniorId}/audios`)
        .then(res => res.json())
        .then(data => {
          this.audioList = data.audio || [];
        })
        .catch(err => console.error(err));
    },

    audioPath(filename) {
      return `/senior/static/audio/${filename}`;
    },

    playAudio(index) {
      this.currentAudioIndex = index;
      const audioEl = this.$refs.audioPlayer;
      if (!audioEl) return;
      audioEl.playbackRate = this.playbackRate;
      audioEl.play();
      this.isPlaying = true;

      audioEl.ontimeupdate = () => {
        this.progress = (audioEl.currentTime / audioEl.duration) * 100;
      };
    },

    togglePlay() {
      const audioEl = this.$refs.audioPlayer;
      if (!audioEl) return;
      if (this.isPlaying) audioEl.pause();
      else audioEl.play();
      this.isPlaying = !this.isPlaying;
    },

    nextAudio() {
      if (this.currentAudioIndex === null) return;
      this.currentAudioIndex = (this.currentAudioIndex + 1) % this.audioList.length;
      this.playAudio(this.currentAudioIndex);
    },

    prevAudio() {
      if (this.currentAudioIndex === null) return;
      this.currentAudioIndex = (this.currentAudioIndex - 1 + this.audioList.length) % this.audioList.length;
      this.playAudio(this.currentAudioIndex);
    },

    changeSpeed() {
      const audioEl = this.$refs.audioPlayer;
      if (audioEl) audioEl.playbackRate = this.playbackRate;
    },

    seekAudio(event) {
      const audioEl = this.$refs.audioPlayer;
      if (!audioEl) return;

      const rect = event.currentTarget.getBoundingClientRect();
      const clickX = event.clientX - rect.left;
      const newTime = (clickX / rect.width) * audioEl.duration;

      audioEl.currentTime = newTime;
      this.progress = (audioEl.currentTime / audioEl.duration) * 100;
    },

    goBack() {
      this.$router.push('/senior/dashboard');
    }
  },

  mounted() {
    this.loadAudio();
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  }
};
