export default {
  template: `
    <div class="games-page container-fluid py-4">

      <!-- Header Card -->
      <div class="glass-card p-4 shadow-lg mb-4 d-flex justify-content-between align-items-center flex-wrap">
        <h1 class="fw-bold text-dark mb-0">Games</h1>
        <button class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold" @click="goBack">
            <i class="fas fa-arrow-left me-2"></i>Back
        </button>
      </div>

      <!-- Popular Classic Games -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h3 class="mb-3 text-warning"><i class="fas fa-star me-2"></i>Popular Classic Games</h3>
        <div class="row">
          <div class="col-md-4 mb-4" v-for="game in popularClassicGames" :key="game.name">
            <div class="glass-card p-4 shadow-lg text-center clickable" @click="openGame(game.url)">
              <h1 class="mb-3">{{ game.emoji }}</h1>
              <h5 class="fw-bold">{{ game.name }}</h5>
              <p class="text-muted">{{ game.desc }}</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Retro Games -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h3 class="mb-3 text-info"><i class="fas fa-history me-2"></i>Retro Games</h3>
        <div class="row">
          <div class="col-md-4 mb-4" v-for="game in retroGames" :key="game.name">
            <div class="glass-card p-4 shadow-lg text-center clickable" @click="openGame(game.url)">
              <h1 class="mb-3">{{ game.emoji }}</h1>
              <h5 class="fw-bold">{{ game.name }}</h5>
              <p class="text-muted">{{ game.desc }}</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Puzzle Games -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h3 class="mb-3 text-success"><i class="fas fa-puzzle-piece me-2"></i>Puzzle Games</h3>
        <div class="row">
          <div class="col-md-4 mb-4" v-for="game in puzzleGames" :key="game.name">
            <div class="glass-card p-4 shadow-lg text-center clickable" @click="openGame(game.url)">
              <h1 class="mb-3">{{ game.emoji }}</h1>
              <h5 class="fw-bold">{{ game.name }}</h5>
              <p class="text-muted">{{ game.desc }}</p>
            </div>
          </div>
        </div>
      </div>

      <!-- Math Puzzle Games -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h3 class="mb-3 text-primary"><i class="fas fa-calculator me-2"></i>Math Puzzle Games</h3>
        <div class="row">
          <div class="col-md-4 mb-4" v-for="game in mathPuzzleGames" :key="game.name">
            <div class="glass-card p-4 shadow-lg text-center clickable" @click="openGame(game.url)">
              <h1 class="mb-3">{{ game.emoji }}</h1>
              <h5 class="fw-bold">{{ game.name }}</h5>
              <p class="text-muted">{{ game.desc }}</p>
            </div>
          </div>
        </div>
      </div>

    </div>
  `,

  data() {
    return {
      popularClassicGames: [
        { name: 'Tetris', url: 'https://tetris.com/play-tetris', emoji: '🟦🟪🟩🟧', desc: 'Classic block puzzle game.' },
        { name: 'Snake', url: 'https://playsnake.org/', emoji: '🐍🍎', desc: 'Grow the snake without hitting walls.' },
        { name: 'Pac-Man', url: 'https://www.retrogames.cc/arcade-games/pac-man.html', emoji: '👻🍒', desc: 'Navigate the maze and eat pellets.' },
      ],
      retroGames: [
        { name: 'Space Invaders', url: 'https://www.retrogames.cc/arcade-games/space-invaders.html', emoji: '👾🚀', desc: 'Shoot aliens and survive.' },
        { name: 'Donkey Kong', url: 'https://www.retrogames.cc/arcade-games/donkey-kong.html', emoji: '🦍🏗️', desc: 'Rescue the princess from Donkey Kong.' },
        { name: 'Frogger', url: 'https://www.retrogames.cc/arcade-games/frogger.html', emoji: '🐸🚦', desc: 'Cross the road and rivers safely.' },
      ],
      puzzleGames: [
        { name: 'Sudoku', url: 'https://www.websudoku.com/', emoji: '🔢🧩', desc: 'Classic number puzzle game.' },
        { name: '2048', url: 'https://play2048.co/', emoji: '2️⃣0️⃣4️⃣8️⃣', desc: 'Combine numbers to reach 2048.' },
        { name: 'Jigsaw', url: 'https://www.jigsawexplorer.com/', emoji: '🧩🖼️', desc: 'Assemble the picture pieces.' },
      ],
      mathPuzzleGames: [
        { name: 'Math Mahjong', url: 'https://www.mathplayground.com/logic_math_mahjong.html', emoji: '🀄➕➖', desc: 'Solve math-based mahjong puzzles.' },
        { name: 'Arithmetic Game', url: 'https://www.coolmathgames.com/0-arithmetic-game', emoji: '➕➖✖️➗', desc: 'Test your arithmetic skills.' },
        { name: 'Number Maze', url: 'https://www.coolmathgames.com/0-number-maze', emoji: '🔢🌀', desc: 'Navigate the maze using numbers.' },
      ]
    };
  },

  methods: {
    openGame(url) {
      window.open(url, "_blank");
    },
    goBack() {
      this.$router.push('/senior/dashboard');
    }
  },

  mounted() {
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  }
};
