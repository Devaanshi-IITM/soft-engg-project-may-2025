const GuardianMessages = {
  template: `
    <div class="guardian-messages container-fluid py-4">
      <!-- Header -->
      <div class="glass-card p-4 shadow-lg mb-4 d-flex justify-content-between align-items-center">
        <h1 class="fw-bold text-dark">Messages</h1>
        <button class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold" @click="goBack">
            <i class="fas fa-arrow-left me-2"></i>Back
          </button>
      </div>

      <!-- Select Senior -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <label for="seniorSelect" class="form-label fw-semibold">Select Senior:</label>
        <select id="seniorSelect" class="form-select" v-model="selectedSeniorId" @change="loadMessages">
          <option value="" disabled selected>Select a senior</option>
          <option v-for="s in seniors" :key="s.id" :value="s.id">
            {{ s.name }} ({{ s.phone }})
          </option>
        </select>
      </div>

      <!-- Chat Box -->
      <div v-if="selectedSeniorId" class="glass-card p-4 shadow-lg mb-4">
        <div ref="chatBox" class="border rounded p-3 mb-3" style="max-height: 400px; overflow-y: auto;">
          <div v-for="m in messages" :key="m.id" class="mb-2" :class="{'text-end': m.sender_role === 'guardian'}">
            <div 
              :class="['p-2 rounded', m.sender_role === 'guardian' ? 'bg-success text-white' : 'bg-primary text-white']"
              style="display: inline-block; max-width: 75%;"
            >
              <small class="d-block mb-1">
                {{ m.sender_role === 'guardian' ? 'You' : 'Senior' }} • {{ formatTime(m.timestamp) }}
              </small>
              {{ m.content }}
            </div>
          </div>
          <div v-if="messages.length === 0" class="text-muted text-center mt-2">No messages yet.</div>
        </div>

        <!-- Input & Send -->
        <div class="input-group align-items-center">
          <input 
            v-model="newMessage" 
            class="form-control border-0 shadow-none" 
            placeholder="Type a message..." 
            @keyup.enter="sendMessage"
            style="height: 48px;"
          >
          <button 
            class="btn btn-primary d-flex align-items-center justify-content-center" 
            style="height: 48px; width: 48px; border-radius: 50%;" 
            @click="sendMessage"
          >
            <i class="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>

      <div v-else class="text-center text-muted my-5">
        <p>Select a senior to start messaging.</p>
      </div>
    </div>
  `,

  data() {
    return {
      guardianId: localStorage.getItem('guardian_id') || null,
      seniors: [],
      selectedSeniorId: null, // start with no selection
      messages: [],
      newMessage: ''
    };
  },

  mounted() {
    if (!this.guardianId) {
      alert("Please log in first.");
      this.$router.push('/guardian/login');
      return;
    }
    this.fetchSeniors();
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  },

  methods: {
    async fetchSeniors() {
      try {
        const res = await fetch(`/guardian/${this.guardianId}/seniors`);
        const data = await res.json();
        this.seniors = data.seniors || [];
        // Removed automatic selection of first senior
      } catch (err) {
        console.error("Error loading seniors:", err);
        alert("Failed to load seniors.");
      }
    },

    async loadMessages() {
      if (!this.selectedSeniorId) return;

      try {
        const res = await fetch(`/senior/messages/${this.selectedSeniorId}`);
        const data = await res.json();
        this.messages = (data.messages || []).sort(
          (a, b) => new Date(a.timestamp) - new Date(b.timestamp)
        );
        this.$nextTick(() => this.scrollToBottom());
      } catch (err) {
        console.error("Error loading messages:", err);
      }
    },

    sendMessage() {
      if (!this.newMessage.trim() || !this.selectedSeniorId) return;

      const payload = { content: this.newMessage };

      fetch(`/guardian/${this.guardianId}/senior/${this.selectedSeniorId}/messages/send`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
        .then(res => res.json())
        .then(data => {
          if (data.id) {
            this.messages.push({
              id: data.id,
              sender_role: data.sender_role,
              content: data.content,
              timestamp: data.timestamp
            });
            this.newMessage = '';
            this.$nextTick(() => this.scrollToBottom());
          } else {
            alert(data.error || 'Failed to send message');
          }
        })
        .catch(err => {
          console.error("Send message error:", err);
          alert("Failed to send message.");
        });
    },

    scrollToBottom() {
      const el = this.$refs.chatBox;
      if (el) el.scrollTop = el.scrollHeight;
    },

    formatTime(ts) {
      const d = new Date(ts);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    },

    goBack() {
      this.$router.push('/guardian/dashboard');
    }
  }
};

export default GuardianMessages;
