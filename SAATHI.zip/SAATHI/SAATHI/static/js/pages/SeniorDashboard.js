export default {
  template: `
    <div class="senior-dashboard container-fluid py-4">

      <!-- Welcome Card -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <div class="d-flex justify-content-between align-items-center flex-wrap">
          <div>
            <h1 class="fw-bold text-dark">Hello, {{ senior.name || 'Senior' }}</h1>
            <p class="lead text-muted">Here’s your wellness dashboard</p>
          </div>
          <div class="d-flex gap-2">
            <button class="btn btn-outline-primary rounded-pill" @click="goToProfile">
              <i class="fas fa-user me-2"></i>Profile
            </button>
            <button class="btn btn-outline-danger rounded-pill" @click="logout">
              <i class="fas fa-sign-out-alt me-2"></i>Logout
            </button>
          </div>
        </div>
      </div>

      <!-- Reminders Card -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h3 class="mb-3 text-warning"><i class="fas fa-bell me-2"></i>Today's Reminders</h3>
        <div class="list-group">
          <div
            v-for="r in reminders"
            :key="r.id"
            class="list-group-item d-flex justify-content-between align-items-center"
            :class="{ 'list-group-item-success': r.is_completed }"
          >
            <span><strong>{{ r.medicine_name }}</strong> at {{ r.reminder_time }}</span>
            <button
              v-if="!r.is_completed"
              @click="markReminderCompleted(r.id)"
              class="btn btn-sm btn-outline-success"
            >
              Mark as Taken
            </button>
            <span v-else class="text-success">
              <i class="fas fa-check-circle me-1"></i> Taken
            </span>
          </div>
          <div v-if="reminders.length === 0" class="text-muted mt-2">No reminders yet.</div>
        </div>
      </div>

      <!-- Appointments Card -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h3 class="mb-3 text-info"><i class="fas fa-calendar-alt me-2"></i>Pending Appointments</h3>
        <div class="list-group">
          <div
            v-for="a in pendingAppointments"
            :key="a.id"
            class="list-group-item d-flex justify-content-between align-items-center"
            :class="{ 'list-group-item-success': a.is_completed }"
          >
            <span><strong>{{ formatDate(a.date) }}</strong> - {{ a.details }}</span>
            <button
              v-if="!a.is_completed"
              @click="markAppointmentCompleted(a.id)"
              class="btn btn-sm btn-outline-success"
            >
              Mark as Completed
            </button>
            <span v-else class="text-success">
              <i class="fas fa-check-circle me-1"></i> Completed
            </span>
          </div>
          <div v-if="pendingAppointments.length === 0" class="text-muted mt-2">No pending appointments.</div>
        </div>
      </div>

      <!-- Navigation Cards -->
      <div class="row">

        <!-- Entertainment -->
        <div class="col-md-4 mb-4">
          <div class="glass-card p-4 shadow-lg text-center clickable" @click="goToEntertainment">
            <i class="fas fa-music fa-2x text-danger mb-3"></i>
            <h4 class="fw-bold">Entertainment</h4>
            <p class="text-muted">Listen to your favorite audios</p>
          </div>
        </div>

        <!-- Games -->
        <div class="col-md-4 mb-4">
          <div class="glass-card p-4 shadow-lg text-center clickable" @click="goToGames">
            <i class="fas fa-gamepad fa-2x text-success mb-3"></i>
            <h4 class="fw-bold">Games</h4>
            <p class="text-muted">Play brain games and puzzles</p>
          </div>
        </div>


        <!-- AI Assistant -->
        <div class="col-md-4 mb-4">
          <div class="glass-card p-4 shadow-lg text-center clickable" @click="showAIChat = !showAIChat">
            <i class="fas fa-robot fa-2x text-primary mb-3"></i>
            <h4 class="fw-bold">AI Assistant</h4>
            <p class="text-muted">Search, ask and chat with AI</p>
          </div>

          <!-- Chatbox -->
          <div v-if="showAIChat" class="glass-card p-4 shadow-lg mt-3 d-flex flex-column" style="height: 400px;">
            
            <!-- Chat Window -->
            <div ref="aiChatBox" class="flex-grow-1 border rounded p-3 mb-3" style="overflow-y: auto;">
              <div 
                v-for="(msg, index) in aiMessages" 
                :key="index" 
                class="mb-2"
                :class="{'text-end': msg.sender === 'user'}"
              >
                <div 
                  :class="['p-2 rounded', msg.sender === 'ai' ? 'bg-primary text-white text-start' : 'bg-success text-white text-end']"
                  style="display: inline-block; max-width: 75%;"
                >
                  <small class="d-block mb-1">
                    {{ msg.sender === 'ai' ? 'AI' : 'You' }} • {{ new Date().toLocaleTimeString([], {hour: '2-digit', minute:'2-digit'}) }}
                  </small>
                  {{ msg.text }}
                </div>
              </div>
              <div v-if="aiMessages.length === 0" class="text-muted text-center mt-2">Start a conversation with AI...</div>
            </div>

            <!-- Input & Buttons -->
            <div class="d-flex align-items-center">
              <input 
                v-model="aiInput" 
                class="form-control border-0 shadow-none rounded-pill me-2" 
                placeholder="Type your message..." 
                @keyup.enter="sendAIMessage"
                style="height: 45px;"
              >
              <button 
                class="btn btn-primary d-flex align-items-center justify-content-center me-2" 
                style="height: 45px; width: 45px; border-radius: 50%;" 
                @click="sendAIMessage"
              >
                <i class="fas fa-paper-plane"></i>
              </button>
              <button 
                @mousedown="startRecording" 
                @mouseup="stopRecording" 
                @mouseleave="stopRecording" 
                class="btn btn-secondary d-flex align-items-center justify-content-center"
                style="height: 45px; width: 45px; border-radius: 50%;"
              >
                <i class="fas fa-microphone"></i>
              </button>
            </div>

            <div v-if="isRecording" class="text-danger mt-2 text-center">
              Recording audio...
            </div>
          </div>
        </div>


      </div>

      <!-- Messages Card -->
      <div class="glass-card p-4 shadow-lg mb-4">
        <h3 class="mb-3 text-primary"><i class="fas fa-comments me-2"></i>Messages</h3>

        <!-- Chat Box -->
        <div ref="chatBox" class="border rounded p-3 mb-3" style="max-height: 300px; overflow-y: auto;">
          <div 
            v-for="m in messages" 
            :key="m.id" 
            class="mb-2" 
            :class="{'text-end': m.sender_role === 'senior'}"
          >
            <div 
              :class="['p-2 rounded', m.sender_role === 'guardian' ? 'bg-primary text-white' : 'bg-success text-white']"
              style="display: inline-block; max-width: 75%;"
            >
              <small class="d-block mb-1">
                {{ m.sender_role === 'guardian' ? 'Guardian' : 'You' }} • {{ formatTime(m.timestamp) }}
              </small>
              {{ m.content }}
            </div>
          </div>
          <div v-if="messages.length === 0" class="text-muted text-center mt-2">No messages yet.</div>
        </div>

        <!-- Input & Send -->
        <div class="input-group align-items-center">
          <input 
            v-model="newMessage" 
            class="form-control border-0 shadow-none" 
            placeholder="Type a message..." 
            @keyup.enter="sendMessage"
            style="height: 48px;"
          >
          <button 
            class="btn btn-primary d-flex align-items-center justify-content-center" 
            style="height: 48px; width: 48px; border-radius: 50%;" 
            @click="sendMessage"
          >
            <i class="fas fa-paper-plane"></i>
          </button>
        </div>
      </div>

    </div>
  `,

  data() {
    return {
      senior: { id: null, name: '', guardian_id: null, guardian_name: null },
      reminders: [],
      appointments: [],
      messages: [],
      newMessage: '',
      audioList: [],
      news: [],

      // AI Chatbot data
      showAIChat: false,
      aiMessages: [],
      aiInput: '',
      isRecording: false,
      mediaRecorder: null,
      audioChunks: []
    };
  },

  computed: {
    pendingAppointments() {
      return this.appointments.filter(a => !a.is_completed);
    }
  },

  methods: {
    loadData() {
      const id = localStorage.getItem('senior_id');
      if (!id) {
        alert("Not logged in.");
        this.$router.push('/');
        return;
      }

      fetch(`/senior/${id}/dashboard`)
        .then(res => res.json())
        .then(data => {
          this.senior = data.senior;
          this.reminders = data.reminders;
          this.appointments = data.appointments || [];
          this.audioList = data.audio;
          this.news = data.news;
          this.messages = data.messages.sort((a, b) => new Date(a.timestamp) - new Date(b.timestamp));
          this.$nextTick(() => this.scrollToBottom());
        })
        .catch(err => console.error(err));
    },

    sendAIMessage() {
      const message = this.aiInput.trim();
      if (!message) {
        return;
      }
      this.aiMessages.push({ sender: 'user', text: message });
      this.aiInput = '';
      this.callChatAPI(message);
    },

    callChatAPI(message) {
      fetch('/ai/chat/', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ text: message })
      })
        .then(res => res.json())
        .then(data => {
          if (data.response) {
            this.aiMessages.push({ sender: 'ai', text: data.response });
            this.$nextTick(() => {
              const el = this.$el.querySelector('.ai-chat-container .chat-window');
              if (el) el.scrollTop = el.scrollHeight;
            });
          } else {
            this.aiMessages.push({ sender: 'ai', text: "Sorry, no response from AI." });
          }
        })
        .catch(() => {
          this.aiMessages.push({ sender: 'ai', text: "Error connecting to AI service." });
        });
    },

    startRecording() {
      if (this.isRecording) return; // Already recording
      // Use MediaRecorder if supported
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        alert("Audio recording not supported by this browser.");
        return;
      }

      navigator.mediaDevices.getUserMedia({ audio: true })
        .then(stream => {
          this.mediaRecorder = new MediaRecorder(stream);
          this.audioChunks = [];
          this.mediaRecorder.ondataavailable = event => {
            if (event.data.size > 0) this.audioChunks.push(event.data);
          };
          this.mediaRecorder.onstop = () => {
            const audioBlob = new Blob(this.audioChunks, { type: 'audio/webm' });
            this.sendAudioForTranscription(audioBlob);
            // Stop all tracks to release microphone
            stream.getTracks().forEach(track => track.stop());
          };
          this.mediaRecorder.start();
          this.isRecording = true;
        })
        .catch(err => {
          alert("Could not start audio recording: " + err);
        });
    },

    stopRecording() {
      if (!this.isRecording) return;
      if (this.mediaRecorder && this.mediaRecorder.state !== 'inactive') {
        this.mediaRecorder.stop();
      }
      this.isRecording = false;
    },

    sendAudioForTranscription(audioBlob) {
      const formData = new FormData();
      formData.append('audio_file', audioBlob, 'recording.webm');

      fetch('/ai/transcribe-audio', {
        method: 'POST',
        body: formData
      })
        .then(res => res.json())
        .then(data => {
          if (data.transcribed_text) {
            this.aiInput = data.transcribed_text;
            this.sendAIMessage();
          } else {
            alert('Failed to transcribe audio.');
          }
        })
        .catch(() => {
          alert('Error sending audio for transcription.');
        });
    },

    markReminderCompleted(reminderId) {
      fetch(`/senior/complete_reminder/${reminderId}`, { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            const r = this.reminders.find(r => r.id === reminderId);
            if (r) r.is_completed = true;
          } else {
            alert(data.error || 'Failed to mark as completed');
          }
        });
    },

    markAppointmentCompleted(appointmentId) {
      fetch(`/senior/complete_appointment/${appointmentId}`, { method: 'POST' })
        .then(res => res.json())
        .then(data => {
          if (data.success) {
            const a = this.appointments.find(a => a.id === appointmentId);
            if (a) a.is_completed = true;
          } else {
            alert(data.error || 'Failed to mark appointment as completed');
          }
        });
    },

    sendMessage() {
      if (!this.newMessage.trim()) return;
      if (!this.senior.guardian_id) {
        alert("No guardian assigned.");
        return;
      }

      const payload = {
        senior_id: this.senior.id,
        guardian_id: this.senior.guardian_id,
        sender_id: this.senior.id,
        sender_role: 'senior',
        content: this.newMessage
      };

      fetch('/senior/messages/send', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      })
        .then(res => res.json())
        .then(data => {
          if (data.id) {
            this.messages.push({
              id: data.id,
              sender_role: data.sender_role,
              content: data.content,
              timestamp: data.timestamp
            });
            this.newMessage = '';
            this.$nextTick(() => this.scrollToBottom());
          } else {
            alert(data.error || 'Failed to send message');
          }
        });
    },

    scrollToBottom() {
      const el = this.$refs.chatBox;
      if (el) el.scrollTop = el.scrollHeight;
    },

    formatTime(ts) {
      const d = new Date(ts);
      return d.toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' });
    },

    formatDate(dt) {
      const d = new Date(dt);
      return d.toLocaleString([], { dateStyle: 'medium', timeStyle: 'short' });
    },

    goToProfile() {
      this.$router.push(`/senior/profile`);
    },

    goToEntertainment() {
      this.$router.push('/senior/audios');
    },

    goToGames() {
      this.$router.push('/senior/games');
    },

    goToAssistant() {
      this.$router.push('/senior/assistant');
    },

    logout() {
      localStorage.removeItem('senior_id');
      this.$router.push('/');
    }
  },

  mounted() {
    this.loadData();
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  }
};
