const ManageReminders = {
  template: `
    <div class="container-fluid py-4">

      <!-- Header & Select Senior Card -->
      <div class="glass-card p-4 shadow-lg rounded-4 mb-4">
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap border-bottom pb-3">
          <div>
            <h1 class="fw-bold text-dark mb-1">Manage Reminders</h1>
            <p class="lead text-muted mb-0">Create, update, or delete reminders for your seniors</p>
          </div>
          <button class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold" @click="goBack">
            <i class="fas fa-arrow-left me-2"></i>Back
          </button>
        </div>

        <!-- Select Senior -->
        <div class="mb-4">
          <label class="form-label fw-semibold">Select Senior</label>
          <select v-model="selectedSeniorId" @change="fetchReminders" class="form-select">
            <option disabled value="">-- Select Senior --</option>
            <option v-for="s in seniors" :key="s.id" :value="s.id">{{ s.name }} ({{ s.phone }})</option>
          </select>
        </div>
      </div>

      <!-- Add / Update Reminder Card -->
      <div class="glass-card p-4 shadow-lg rounded-4 mb-4">
        <h5 class="text-primary fw-bold mb-3"><i class="fas fa-plus-circle me-2"></i>{{ reminderForm.id ? 'Update' : 'Add' }} Reminder</h5>
        <form @submit.prevent="saveReminder">
          <div class="mb-3">
            <label class="form-label fw-semibold">Medicine Name</label>
            <input v-model="reminderForm.medicine_name" type="text" class="form-control" placeholder="e.g., Paracetamol" required>
          </div>

          <div class="mb-3">
            <label class="form-label fw-semibold">Reminder Time</label>
            <input v-model="reminderForm.reminder_time" type="time" class="form-control" required>
          </div>

          <div class="text-end mt-3">
            <button type="submit" class="btn btn-primary px-4 py-2 rounded-pill fw-semibold">
              <i class="fas fa-save me-2"></i>{{ reminderForm.id ? 'Update' : 'Add' }} Reminder
            </button>
            <button v-if="reminderForm.id" type="button" class="btn btn-danger px-4 py-2 rounded-pill fw-semibold ms-2" @click="deleteReminder">
              <i class="fas fa-trash me-2"></i>Delete
            </button>
          </div>
        </form>
      </div>

      <!-- Search & Reminders Listing Card -->
      <div class="glass-card p-4 shadow-lg rounded-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
          <h5 class="text-primary fw-bold mb-2"><i class="fas fa-clock me-2"></i>Reminders</h5>
          <input type="text" v-model="searchQuery" placeholder="Search reminders..." class="form-control w-auto">
        </div>

        <ul class="list-group">
          <li v-for="r in filteredReminders" :key="r.id" class="list-group-item d-flex justify-content-between align-items-center cursor-pointer"
              @click="editReminder(r)">
            <div>
              <strong>{{ r.medicine_name }}</strong> at {{ r.reminder_time }}
            </div>
            <span class="badge" :class="r.is_completed ? 'bg-success' : 'bg-secondary'">
              {{ r.is_completed ? 'Done' : 'Pending' }}
            </span>
          </li>
        </ul>

        <div v-if="filteredReminders.length === 0" class="text-muted text-center my-3">
          No reminders found for this senior.
        </div>
      </div>

    </div>
  `,

  data() {
    return {
      guardianId: localStorage.getItem('guardian_id') || null,
      seniors: [],
      selectedSeniorId: '',
      reminders: [],
      searchQuery: '',
      reminderForm: {
        id: null,
        medicine_name: '',
        reminder_time: ''
      }
    };
  },

  mounted() {
    if (!this.guardianId) {
      alert("Please log in first.");
      this.$router.push('/guardian/login');
      return;
    }
    this.fetchSeniors();
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  },

  computed: {
    filteredReminders() {
      return this.reminders.filter(r =>
        r.medicine_name.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }
  },

  methods: {
    async fetchSeniors() {
      try {
        const res = await fetch(`/guardian/${this.guardianId}/seniors`);
        const data = await res.json();
        this.seniors = data.seniors || [];
      } catch (err) {
        console.error("Error fetching seniors:", err);
        alert("Failed to load seniors.");
      }
    },

    async fetchReminders() {
      if (!this.selectedSeniorId) {
        this.reminders = [];
        return;
      }
      try {
        const res = await fetch(`/guardian/${this.guardianId}/senior/${this.selectedSeniorId}/reminders`);
        const data = await res.json();
        this.reminders = data.reminders || [];
        this.clearForm();
      } catch (err) {
        console.error("Error fetching reminders:", err);
        alert("Failed to load reminders.");
      }
    },

    async saveReminder() {
      if (!this.selectedSeniorId) return alert("Please select a senior first.");

      try {
        const url = this.reminderForm.id
          ? `/guardian/${this.guardianId}/reminder/${this.reminderForm.id}`
          : `/guardian/${this.guardianId}/senior/${this.selectedSeniorId}/add_reminder`;
        const method = this.reminderForm.id ? 'PUT' : 'POST';

        const res = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            medicine_name: this.reminderForm.medicine_name,
            reminder_time: this.reminderForm.reminder_time
          })
        });

        const data = await res.json();
        if (res.ok) {
          alert(`Reminder ${this.reminderForm.id ? 'updated' : 'added'} successfully!`);
          this.fetchReminders();
        } else {
          alert(data.error || "Failed to save reminder.");
        }
      } catch (err) {
        console.error("Error saving reminder:", err);
        alert("Something went wrong.");
      }
    },

    editReminder(r) {
      this.reminderForm = { ...r };
    },

    async deleteReminder() {
      if (!this.reminderForm.id) return;
      if (!confirm("Are you sure you want to delete this reminder?")) return;

      try {
        const res = await fetch(`/guardian/${this.guardianId}/reminder/${this.reminderForm.id}`, {
          method: 'DELETE'
        });
        if (res.ok) {
          alert("Reminder deleted successfully!");
          this.fetchReminders();
        } else {
          const data = await res.json();
          alert(data.error || "Failed to delete reminder.");
        }
      } catch (err) {
        console.error("Error deleting reminder:", err);
        alert("Something went wrong.");
      }
    },

    clearForm() {
      this.reminderForm = { id: null, medicine_name: '', reminder_time: '' };
    },

    goBack() {
      this.$router.push('/guardian/dashboard');
    }
  }
};

export default ManageReminders;
