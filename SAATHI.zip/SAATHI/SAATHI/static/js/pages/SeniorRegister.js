const RegisterSenior = {
  template: `
    <div class="container-fluid py-4">
      <div class="glass-card p-4 shadow-lg rounded-4">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-5 flex-wrap border-bottom pb-3">
          <div>
            <h1 class="fw-bold text-dark mb-1">Register Senior</h1>
            <p class="lead text-muted mb-0">Add a new senior under your care</p>
          </div>
          <button class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold" @click="cancel">
            <i class="fas fa-times me-2"></i>Cancel
          </button>
        </div>

        <!-- Register Senior Form -->
        <section>
          <h3 class="mb-4 text-primary fw-bold">
            <i class="fas fa-id-card me-2"></i>Senior Information
          </h3>

          <form @submit.prevent="registerSenior">
            <div class="row g-4">
              <!-- Name -->
              <div class="col-md-6">
                <div class="card shadow-sm rounded-3 border-0 h-100">
                  <div class="card-body">
                    <div class="mb-3">
                      <label class="form-label fw-bold text-muted">Full Name</label>
                      <input v-model="senior.name" type="text" required
                        class="form-control rounded-3" placeholder="Enter senior's full name" />
                    </div>
                  </div>
                </div>
              </div>

              <!-- Phone -->
              <div class="col-md-6">
                <div class="card shadow-sm rounded-3 border-0 h-100">
                  <div class="card-body">
                    <div class="mb-3">
                      <label class="form-label fw-bold text-muted">Phone Number</label>
                      <input v-model="senior.phone" type="text" required
                        class="form-control rounded-3" placeholder="e.g. 9876543210" />
                    </div>
                  </div>
                </div>
              </div>
            </div>

            <!-- Action Buttons -->
            <div class="mt-5 text-end">
              <button type="submit" class="btn btn-primary px-4 py-2 rounded-pill fw-semibold">
                <i class="fas fa-user-plus me-2"></i>Register Senior
              </button>
            </div>
          </form>
        </section>

      </div>
    </div>
  `,

  data() {
    return {
      guardianId: localStorage.getItem('guardian_id') || null,
      senior: {
        name: "",
        phone: ""
      }
    };
  },

  methods: {
    async registerSenior() {
      if (!this.guardianId) {
        alert("Guardian not logged in.");
        this.$router.push('/guardian/login');
        return;
      }

      try {
        const res = await fetch(`/guardian/${this.guardianId}/register_senior`, {
          method: "POST",
          headers: { "Content-Type": "application/json" },
          body: JSON.stringify(this.senior)
        });

        const data = await res.json();

        if (res.ok) {
          alert("Senior registered successfully!");
          this.$router.push('/guardian/dashboard');
        } else {
          alert(data.error || "Failed to register senior.");
        }
      } catch (err) {
        console.error("Error registering senior:", err);
        alert("Something went wrong.");
      }
    },

    cancel() {
      this.$router.push('/guardian/dashboard');
    }
  },

  mounted() {
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  }
};

export default RegisterSenior;
