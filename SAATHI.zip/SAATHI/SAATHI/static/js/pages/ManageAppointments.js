const ManageAppointments = {
  template: `
    <div class="container-fluid py-4">
      <div class="glass-card p-4 shadow-lg rounded-4 mb-4">

        <!-- Header -->
        <div class="d-flex justify-content-between align-items-center mb-4 flex-wrap border-bottom pb-3">
          <div>
            <h1 class="fw-bold text-dark mb-1">Manage Appointments</h1>
            <p class="lead text-muted mb-0">Create, update, or delete appointments for your seniors</p>
          </div>
          <button class="btn btn-outline-secondary px-4 py-2 rounded-pill fw-semibold" @click="goBack">
            <i class="fas fa-arrow-left me-2"></i>Back
          </button>
        </div>

        <!-- Select Senior -->
        <div class="mb-4">
          <label class="form-label fw-semibold">Select Senior</label>
          <select v-model="selectedSeniorId" @change="fetchAppointments" class="form-select">
            <option disabled value="">-- Select Senior --</option>
            <option v-for="s in seniors" :key="s.id" :value="s.id">{{ s.name }} ({{ s.phone }})</option>
          </select>
        </div>
      </div>

      <!-- Add / Update Appointment Card -->
      <div class="glass-card p-4 shadow-lg rounded-4 mb-4">
        <h5 class="text-primary fw-bold mb-3"><i class="fas fa-plus-circle me-2"></i>{{ appointmentForm.id ? 'Update' : 'Add' }} Appointment</h5>
        <form @submit.prevent="saveAppointment">
          <div class="mb-3">
            <label class="form-label fw-semibold">Appointment Details</label>
            <textarea v-model="appointmentForm.details" class="form-control" placeholder="Enter appointment details" required></textarea>
          </div>

          <div class="row g-3 mb-3">
            <div class="col-md-6">
              <label class="form-label fw-semibold">Date</label>
              <input v-model="appointmentForm.date" type="date" class="form-control" required>
            </div>
            <div class="col-md-6">
              <label class="form-label fw-semibold">Time</label>
              <input v-model="appointmentForm.time" type="time" class="form-control" required>
            </div>
          </div>

          <div class="form-check mb-3">
            <input class="form-check-input" type="checkbox" id="isCompleted" v-model="appointmentForm.is_completed">
            <label class="form-check-label" for="isCompleted">
              Mark as Completed
            </label>
          </div>

          <div class="text-end mt-3">
            <button type="submit" class="btn btn-primary px-4 py-2 rounded-pill fw-semibold">
              <i class="fas fa-save me-2"></i>{{ appointmentForm.id ? 'Update' : 'Add' }} Appointment
            </button>
            <button v-if="appointmentForm.id" type="button" class="btn btn-danger px-4 py-2 rounded-pill fw-semibold ms-2" @click="deleteAppointment">
              <i class="fas fa-trash me-2"></i>Delete
            </button>
          </div>
        </form>
      </div>

      <!-- Search & Appointment Listing Card -->
      <div class="glass-card p-4 shadow-lg rounded-4">
        <div class="d-flex justify-content-between align-items-center mb-3 flex-wrap">
          <h5 class="text-primary fw-bold mb-2"><i class="fas fa-calendar-check me-2"></i>Appointments</h5>
          <input type="text" v-model="searchQuery" placeholder="Search appointments..." class="form-control w-auto">
        </div>

        <ul class="list-group">
          <li v-for="a in filteredAppointments" :key="a.id" class="list-group-item d-flex justify-content-between align-items-center cursor-pointer"
              @click="editAppointment(a)">
            <div>
              <strong>{{ formatDate(a.date) }}</strong> — {{ a.details }}
            </div>
            <span class="badge" :class="a.is_completed ? 'bg-success' : 'bg-secondary'">
              {{ a.is_completed ? 'Completed' : 'Pending' }}
            </span>
          </li>
        </ul>

        <div v-if="filteredAppointments.length === 0" class="text-muted text-center my-3">
          No appointments found for this senior.
        </div>
      </div>
    </div>
  `,

  data() {
    return {
      guardianId: localStorage.getItem('guardian_id') || null,
      seniors: [],
      selectedSeniorId: '',
      appointments: [],
      searchQuery: '',
      appointmentForm: {
        id: null,
        details: '',
        date: '',
        time: '',
        is_completed: false
      }
    };
  },

  mounted() {
    if (!this.guardianId) {
      alert("Please log in first.");
      this.$router.push('/guardian/login');
      return;
    }
    this.fetchSeniors();
    document.body.classList.add('senior-dashboard-bg');
  },

  beforeDestroy() {
    document.body.classList.remove('senior-dashboard-bg');
  },

  computed: {
    filteredAppointments() {
      return this.appointments.filter(a =>
        a.details.toLowerCase().includes(this.searchQuery.toLowerCase())
      );
    }
  },

  methods: {
    async fetchSeniors() {
      try {
        const res = await fetch(`/guardian/${this.guardianId}/seniors`);
        const data = await res.json();
        this.seniors = data.seniors || [];

        // Automatically select senior from URL query if provided
        const params = new URLSearchParams(window.location.search);
        const seniorId = params.get('senior_id');
        if (seniorId && this.seniors.some(s => s.id === parseInt(seniorId))) {
          this.selectedSeniorId = parseInt(seniorId);
          this.fetchAppointments();
        }
      } catch (err) {
        console.error("Error fetching seniors:", err);
        alert("Failed to load seniors.");
      }
    },

    async fetchAppointments() {
      if (!this.selectedSeniorId) {
        this.appointments = [];
        return;
      }
      try {
        const res = await fetch(`/guardian/${this.guardianId}/senior/${this.selectedSeniorId}/appointments`);
        const data = await res.json();
        this.appointments = data.appointments || [];
        this.clearForm();
      } catch (err) {
        console.error("Error fetching appointments:", err);
        alert("Failed to load appointments.");
      }
    },

    async saveAppointment() {
      if (!this.selectedSeniorId) return alert("Please select a senior first.");
      const datetimeStr = `${this.appointmentForm.date}T${this.appointmentForm.time}:00`;

      try {
        const url = this.appointmentForm.id
          ? `/guardian/${this.guardianId}/appointment/${this.appointmentForm.id}`
          : `/guardian/${this.guardianId}/senior/${this.selectedSeniorId}/add_appointment`;
        const method = this.appointmentForm.id ? 'PUT' : 'POST';

        const res = await fetch(url, {
          method,
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            details: this.appointmentForm.details,
            date: datetimeStr,
            is_completed: this.appointmentForm.is_completed
          })
        });

        const data = await res.json();
        if (res.ok) {
          alert(`Appointment ${this.appointmentForm.id ? 'updated' : 'added'} successfully!`);
          this.fetchAppointments();
        } else {
          alert(data.error || "Failed to save appointment.");
        }
      } catch (err) {
        console.error("Error saving appointment:", err);
        alert("Something went wrong.");
      }
    },

    editAppointment(a) {
      const dt = new Date(a.date);
      this.appointmentForm = {
        id: a.id,
        details: a.details,
        date: dt.toISOString().split('T')[0],
        time: dt.toTimeString().slice(0,5),
        is_completed: a.is_completed
      };
    },

    async deleteAppointment() {
      if (!this.appointmentForm.id) return;
      if (!confirm("Are you sure you want to delete this appointment?")) return;

      try {
        const res = await fetch(`/guardian/${this.guardianId}/appointment/${this.appointmentForm.id}`, {
          method: 'DELETE'
        });
        if (res.ok) {
          alert("Appointment deleted successfully!");
          this.fetchAppointments();
        } else {
          const data = await res.json();
          alert(data.error || "Failed to delete appointment.");
        }
      } catch (err) {
        console.error("Error deleting appointment:", err);
        alert("Something went wrong.");
      }
    },

    clearForm() {
      this.appointmentForm = { id: null, details: '', date: '', time: '', is_completed: false };
    },

    formatDate(dtStr) {
      const dt = new Date(dtStr);
      return dt.toLocaleString([], { dateStyle: 'short', timeStyle: 'short' });
    },

    goBack() {
      this.$router.push('/guardian/dashboard');
    }
  }
};

export default ManageAppointments;
