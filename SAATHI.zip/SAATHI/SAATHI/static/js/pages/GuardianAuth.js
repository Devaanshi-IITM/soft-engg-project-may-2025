// static/js/pages/GuardianAuth.js

export default {
    template: `
      <div class="auth-wrapper">
        <div class="auth-card">
          <div class="app-header">
            <h1>Saathi</h1>
            <p>Your Digital Companion for Comfort, Care & Connection</p>
          </div>
  
          <div class="back-link-left">
            <router-link to="/" class="btn btn-light border">
              <i class="fas fa-arrow-left me-2"></i>Back to Senior Login
            </router-link>
          </div>
  
          <div class="row g-0">
            <!-- Register Section -->
            <div class="col-md-6 pe-md-4">
              <h2 class="section-title"><i class="fas fa-user-plus me-2 text-warning"></i>Register</h2>
              <div class="mb-3">
                <label class="form-label">Full Name</label>
                <input v-model="name" class="form-control" placeholder="e.g., Priya Sharma">
              </div>
              <div class="mb-3">
                <label class="form-label">Phone Number</label>
                <input v-model="phone" class="form-control" placeholder="10-digit mobile">
              </div>
              <div class="mb-3">
                <label class="form-label">Password</label>
                <input v-model="password" type="password" class="form-control" placeholder="Enter password">
              </div>
              <button class="btn btn-primary w-100" @click="register">
                <i class="fas fa-user-plus me-1"></i> Register
              </button>
            </div>
  
            <!-- Divider -->
            <div class="col-md-1 d-none d-md-block auth-divider"></div>
  
            <!-- Login Section -->
            <div class="col-md-5 ps-md-4 mt-4 mt-md-0">
              <h2 class="section-title"><i class="fas fa-sign-in-alt me-2 text-warning"></i>Login</h2>
              <div class="mb-3">
                <label class="form-label">Phone Number</label>
                <input v-model="loginPhone" class="form-control" placeholder="10-digit mobile">
              </div>
              <div class="mb-3">
                <label class="form-label">Password</label>
                <input v-model="loginPassword" type="password" class="form-control" placeholder="Enter password">
              </div>
              <button class="btn btn-primary w-100" @click="login">
                <i class="fas fa-sign-in-alt me-1"></i> Login
              </button>
            </div>
          </div>
        </div>
      </div>
    `,
  
    data() {
      return {
        name: '',
        phone: '',
        password: '',
        loginPhone: '',
        loginPassword: ''
      };
    },
  
    mounted() {
      document.body.style.background = 'linear-gradient(to right, #FFEFBA, #FDB813)';
    },
  
    beforeDestroy() {
      document.body.style.background = '';
    },
  
    methods: {
      register() {
        fetch('/guardian/register', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            name: this.name,
            phone: this.phone,
            password: this.password
          })
        })
        .then(res => res.json())
        .then(data => alert(data.message || data.error));
      },
  
      login() {
        fetch('/guardian/login', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({
            phone: this.loginPhone,
            password: this.loginPassword
          })
        })
        .then(res => res.json())
        .then(data => {
          if (data.guardian_id) {
            alert(`Welcome ${data.name}!`);
            localStorage.setItem('guardian_id', data.guardian_id);
            this.$router.push('/guardian/dashboard');
          } else {
            alert(data.error);
          }
        });
      }
    }
  };