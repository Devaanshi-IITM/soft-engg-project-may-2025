# from flask import Blueprint
from .senior_api import create_senior_api
from .guardian_api import create_guardian_api
from .ai_api import create_ai_interaction

def register_blueprints(app, db_session):
    app.register_blueprint(create_senior_api(db_session), url_prefix='/senior')
    app.register_blueprint(create_guardian_api(db_session), url_prefix='/guardian')
    app.register_blueprint(create_ai_interaction(db_session), url_prefix='/ai')
