from flask import Blueprint, request, jsonify, session, send_from_directory, current_app
from models import Senior, Reminder, Message, Audio, Update, ReminderLog, Guardian, Appointment
import random
from datetime import datetime , time , timedelta
import os
import threading
import time

def create_senior_api(db_session):
    senior_api = Blueprint('senior_api', __name__)
    otp_store = {}

    # ---------------- OTP Routes ----------------
    @senior_api.route('/send_otp', methods=['POST'])
    def send_otp():
        data = request.json
        phone = data.get('phone')
        senior = db_session.query(Senior).filter_by(phone=phone).first()
        if not senior:
            return jsonify({'error': 'Senior not found'}), 404

        otp = random.randint(100000, 999999)
        otp_store[phone] = otp
        print(f"[DEBUG] OTP for {phone} is {otp}")

        return jsonify({'message': 'OTP sent'}), 200

    @senior_api.route('/verify_otp', methods=['POST'])
    def verify_otp():
        data = request.json
        phone = data.get('phone')
        otp = int(data.get('otp'))
        if otp_store.get(phone) == otp:
            senior = db_session.query(Senior).filter_by(phone=phone).first()
            return jsonify({
                'message': 'Login successful',
                'senior_id': senior.id,
                'name': senior.name
            }), 200
        return jsonify({'error': 'Invalid OTP'}), 401

    # ---------------- Dashboard ----------------
    @senior_api.route('/<int:senior_id>/dashboard', methods=['GET'])
    def senior_dashboard(senior_id):
        senior = db_session.query(Senior).filter_by(id=senior_id).first()
        if not senior:
            return jsonify({'error': 'Senior not found'}), 404

        guardian = db_session.query(Guardian).filter_by(id=senior.guardian_id).first()
        reminders = db_session.query(Reminder).filter_by(senior_id=senior_id).all()
        appointments = db_session.query(Appointment).filter_by(senior_id=senior_id).all()
        messages = db_session.query(Message).filter_by(senior_id=senior_id).order_by(Message.timestamp).all()
        audio = db_session.query(Audio).filter_by(senior_id=senior_id).all()
        news = db_session.query(Update).all()

        return jsonify({
            'senior': {
                'id': senior.id,
                'name': senior.name,
                'guardian_id': guardian.id if guardian else None,
                'guardian_name': guardian.name if guardian else None
            },
            'reminders': [
                {
                    'id': r.id,
                    'medicine_name': r.medicine_name,
                    'reminder_time': r.reminder_time.strftime('%H:%M') if r.reminder_time else None,
                    'is_completed': r.is_completed
                } for r in reminders
            ],
            'appointments': [
                {
                    'id': a.id,
                    'date': a.date.isoformat() if a.date else None,
                    'details': a.details,
                    'is_completed': a.is_completed
                } for a in appointments
            ],
            'messages': [
                {
                    'id': m.id,
                    'sender_role': m.sender_role,
                    'content': m.content,
                    'timestamp': m.timestamp.isoformat()
                } for m in messages
            ],
            'audio': [
                {
                    'id': a.id,
                    'title': a.title,
                    'filename': a.filename
                } for a in audio
            ],
            'news': [
                {
                    'id': n.id,
                    'title': n.title,
                    'content': n.content
                } for n in news
            ]
        })

    # ---------------- Complete Reminder ----------------
    @senior_api.route('/complete_reminder/<int:reminder_id>', methods=['POST'])
    def complete_reminder(reminder_id):
        reminder = db_session.query(Reminder).filter_by(id=reminder_id).first()
        if not reminder:
            return jsonify({'error': 'Reminder not found'}), 404

        reminder.is_completed = True
        db_session.commit()

        # schedule reset in 500 seconds 🚀
        schedule_reminder_reset(db_session, reminder.id, delay=10)

        log = ReminderLog(reminder_id=reminder_id, completed_by='senior')
        db_session.add(log)
        db_session.commit()
        return jsonify({'success': True})
    
    def schedule_reminder_reset(db_session, reminder_id, delay=10):
        """Background reset of reminder.is_completed after delay seconds"""
        def reset_task():
            time.sleep(delay)
            reminder = db_session.query(Reminder).get(reminder_id)
            if reminder and reminder.is_completed:  # only reset if still completed
                reminder.is_completed = False
                db_session.commit()
                print(f"[DEBUG] Reminder {reminder_id} auto-reset after {delay} seconds")

        threading.Thread(target=reset_task, daemon=True).start()

    '''def schedule_reminder_reset(db_session, reminder_id):
    """Reset reminder.is_completed at midnight"""
    def reset_task():
        # Calculate next midnight
        now = datetime.now()
        tomorrow = now + timedelta(days=1)
        midnight = datetime.combine(tomorrow.date(), datetime.min.time())
        delay = (midnight - now).total_seconds()

        print(f"[DEBUG] Reminder {reminder_id} will reset at {midnight} ({delay:.0f} sec)")

        # Sleep until midnight
        time.sleep(delay)

        reminder = db_session.query(Reminder).get(reminder_id)
        if reminder and reminder.is_completed:  # only reset if still completed
            reminder.is_completed = False
            db_session.commit()
            print(f"[DEBUG] Reminder {reminder_id} auto-reset at midnight")

    threading.Thread(target=reset_task, daemon=True).start()'''

    # ---------------- Complete Appointment ----------------
    @senior_api.route('/complete_appointment/<int:appointment_id>', methods=['POST'])
    def complete_appointment(appointment_id):
        appointment = db_session.query(Appointment).filter_by(id=appointment_id).first()
        if not appointment:
            return jsonify({'error': 'Appointment not found'}), 404

        appointment.is_completed = True
        db_session.commit()
        return jsonify({'success': True})

    # ---------------- Senior Profile ----------------
    @senior_api.route('/<int:user_id>/profile', methods=['GET'])
    def senior_profile(user_id):
        user = db_session.query(Senior).filter_by(id=user_id).first()
        if not user:
            return jsonify({'error': 'User not found'}), 404
        guardian = db_session.query(Guardian).filter_by(id=user.guardian_id).first()
        return jsonify({
            'user': {
                'id': user.id,
                'name': user.name,
                'phone': user.phone,
                'guardian': {
                    'id': guardian.id if guardian else None,
                    'name': guardian.name if guardian else None,
                    'phone': guardian.phone if guardian else None,
                }
            }
        })

    # ---------------- Messages ----------------
    @senior_api.route('/messages/<int:senior_id>', methods=['GET'])
    def get_messages(senior_id):
        messages = db_session.query(Message).filter_by(senior_id=senior_id).order_by(Message.timestamp).all()
        return jsonify({
            'messages': [
                {
                    'id': m.id,
                    'sender_role': m.sender_role,
                    'content': m.content,
                    'timestamp': m.timestamp.isoformat()
                } for m in messages
            ]
        })

    @senior_api.route('/messages/send', methods=['POST'])
    def send_message():
        data = request.json
        senior_id = data.get('senior_id')
        guardian_id = data.get('guardian_id')
        sender_role = data.get('sender_role')
        sender_id = data.get('sender_id')
        content = data.get('content')

        if not all([senior_id, sender_role, sender_id, content]):
            return jsonify({'error': 'Missing fields'}), 400

        message = Message(
            senior_id=senior_id,
            sender_role=sender_role,
            sender_id=sender_id,
            sender_name=None,
            content=content,
            timestamp=datetime.utcnow()
        )
        db_session.add(message)
        db_session.commit()

        return jsonify({
            'id': message.id,
            'senior_id': message.senior_id,
            'sender_id': message.sender_id,
            'sender_role': message.sender_role,
            'content': message.content,
            'timestamp': message.timestamp.isoformat()
        })

    # ---------------- Audios ----------------
    @senior_api.route('/<int:senior_id>/audios', methods=['GET'])
    def get_audios(senior_id):
        senior = db_session.query(Senior).filter_by(id=senior_id).first()
        if not senior:
            return jsonify({'error': 'Senior not found'}), 404

        query = request.args.get('q', '').lower()
        audios = db_session.query(Audio).filter_by(senior_id=senior_id).all()
        if query:
            audios = [a for a in audios if query in a.title.lower()]

        result = [{'id': a.id, 'title': a.title, 'filename': a.filename} for a in audios]
        return jsonify({'audio': result})

    # ---------------- Serve Audio ----------------
    @senior_api.route('/static/audio/<string:filename>', methods=['GET'])
    def serve_audio_by_filename(filename):
        audio_folder = os.path.join(current_app.root_path, 'static', 'audio')
        file_path = os.path.join(audio_folder, filename)
        if not os.path.exists(file_path):
            return jsonify({'error': 'File not found'}), 404
        return send_from_directory(audio_folder, filename)

    return senior_api
