# api/guardian_api.py
from flask import Blueprint, request, jsonify, send_file, current_app, Response, abort
from werkzeug.security import generate_password_hash, check_password_hash
from werkzeug.utils import secure_filename
from models import Guardian, Senior, Reminder, Audio, Appointment, Message
from datetime import datetime
import os
import mimetypes
import uuid
import re
import json


# ---------- Config ----------
UPLOAD_FOLDER = os.path.join("static", "audio")
ALLOWED_EXTENSIONS = {"mp3", "wav", "m4a"}
os.makedirs(UPLOAD_FOLDER, exist_ok=True)


def _allowed_file(filename: str) -> bool:
    return "." in filename and filename.rsplit(".", 1)[1].lower() in ALLOWED_EXTENSIONS


def _slugify(s: str) -> str:
    s = re.sub(r"[^A-Za-z0-9\-_. ]+", "", s or "").strip().lower()
    s = re.sub(r"\s+", "-", s)
    return s or "audio"


def _unique_filename(original_name: str, title: str = "") -> str:
    """
    Creates a collision-resistant file name:
    {slug(title or original_base)}--{uuid}.{ext}
    """
    base, ext = os.path.splitext(original_name)
    ext = ext.lower().lstrip(".")
    slug = _slugify(title or base)
    uid = uuid.uuid4().hex[:8]
    return f"{slug}--{uid}.{ext}"


def create_guardian_api(db_session):
    guardian_api = Blueprint("guardian_api", __name__)

    # -------------------- AUTH --------------------
    @guardian_api.route("/register", methods=["POST"])
    def register_guardian():
        data = request.json or {}
        name = data.get("name")
        phone = data.get("phone")
        password = data.get("password")

        if not name or not phone or not password:
            return jsonify({"error": "Missing fields"}), 400

        if db_session.query(Guardian).filter_by(phone=phone).first():
            return jsonify({"error": "Guardian already exists"}), 409

        hashed_pw = generate_password_hash(password)
        guardian = Guardian(name=name, phone=phone, password=hashed_pw)
        db_session.add(guardian)
        db_session.commit()

        return jsonify({"message": "Guardian registered successfully"}), 200

    @guardian_api.route("/login", methods=["POST"])
    def login_guardian():
        data = request.json or {}
        phone = data.get("phone")
        password = data.get("password")

        guardian = db_session.query(Guardian).filter_by(phone=phone).first()
        if guardian and check_password_hash(guardian.password, password):
            return jsonify(
                {"message": "Login successful", "guardian_id": guardian.id, "name": guardian.name}
            ), 200
        return jsonify({"error": "Invalid credentials"}), 401

    # -------------------- SENIORS --------------------
    
    @guardian_api.route("/<int:guardian_id>/seniors", methods=["GET"])
    def get_seniors(guardian_id):
        seniors = db_session.query(Senior).filter_by(guardian_id=guardian_id).all()
        return jsonify(
            {"seniors": [{"id": s.id, "name": s.name, "phone": s.phone} for s in seniors]}
        )

    @guardian_api.route("/<int:guardian_id>/register_senior", methods=["POST"])
    def register_senior(guardian_id):
        data = request.get_json() or {}
        name = data.get("name")
        phone = data.get("phone")

        guardian = db_session.query(Guardian).filter_by(id=guardian_id).first()
        if not guardian:
            return jsonify({"error": "Guardian not found"}), 404

        if db_session.query(Senior).filter_by(phone=phone).first():
            return jsonify({"error": "Phone number already registered"}), 400

        senior = Senior(name=name, phone=phone, guardian_id=guardian_id)
        db_session.add(senior)
        db_session.commit()
        return jsonify({"success": True, "senior_id": senior.id})

    # -------------------- REMINDERS --------------------
    @guardian_api.route("/<int:guardian_id>/senior/<int:senior_id>/reminders", methods=["GET"])
    def get_senior_reminders(guardian_id, senior_id):
        senior = db_session.query(Senior).filter_by(id=senior_id, guardian_id=guardian_id).first()
        if not senior:
            return jsonify({"error": "Invalid senior selected"}), 400

        reminders = db_session.query(Reminder).filter_by(senior_id=senior.id).all()
        return jsonify(
            {
                "reminders": [
                    {
                        "id": r.id,
                        "senior_id": senior.id,
                        "senior_name": senior.name,
                        "medicine_name": r.medicine_name,
                        "reminder_time": r.reminder_time.strftime("%H:%M"),
                        "is_completed": r.is_completed,
                    }
                    for r in reminders
                ]
            }
        )

    @guardian_api.route("/<int:guardian_id>/senior/<int:senior_id>/add_reminder", methods=["POST"])
    def add_senior_reminder(guardian_id, senior_id):
        data = request.get_json() or {}
        medicine_name = data.get("medicine_name")
        reminder_time = data.get("reminder_time")

        senior = db_session.query(Senior).filter_by(id=senior_id, guardian_id=guardian_id).first()
        if not senior:
            return jsonify({"error": "Invalid senior selected"}), 400

        reminder = Reminder(
            senior_id=senior_id,
            medicine_name=medicine_name,
            reminder_time=datetime.strptime(reminder_time, "%H:%M").time(),
        )
        db_session.add(reminder)
        db_session.commit()
        return jsonify({"success": True, "reminder_id": reminder.id})

    @guardian_api.route("/<int:guardian_id>/reminder/<int:reminder_id>", methods=["PUT"])
    def update_senior_reminder(guardian_id, reminder_id):
        data = request.get_json() or {}
        reminder = (
            db_session.query(Reminder)
            .join(Senior)
            .filter(Reminder.id == reminder_id, Senior.guardian_id == guardian_id)
            .first()
        )
        if not reminder:
            return jsonify({"error": "Reminder not found"}), 404

        reminder.medicine_name = data.get("medicine_name", reminder.medicine_name)
        reminder_time = data.get("reminder_time")
        if reminder_time:
            reminder.reminder_time = datetime.strptime(reminder_time, "%H:%M").time()
        reminder.is_completed = data.get("is_completed", reminder.is_completed)

        db_session.commit()
        return jsonify({"success": True})

    @guardian_api.route("/<int:guardian_id>/reminder/<int:reminder_id>", methods=["DELETE"])
    def delete_senior_reminder(guardian_id, reminder_id):
        reminder = (
            db_session.query(Reminder)
            .join(Senior)
            .filter(Reminder.id == reminder_id, Senior.guardian_id == guardian_id)
            .first()
        )
        if not reminder:
            return jsonify({"error": "Reminder not found"}), 404

        db_session.delete(reminder)
        db_session.commit()
        return jsonify({"success": True})

    # -------------------- MESSAGES --------------------
    @guardian_api.route("/<int:guardian_id>/senior/<int:senior_id>/messages", methods=["GET"])
    def get_senior_messages(guardian_id, senior_id):
        senior = db_session.query(Senior).filter_by(id=senior_id, guardian_id=guardian_id).first()
        if not senior:
            return jsonify({"error": "Invalid senior selected"}), 400

        messages = (
            db_session.query(Message).filter_by(senior_id=senior_id).order_by(Message.timestamp).all()
        )
        return jsonify(
            {
                "messages": [
                    {
                        "id": m.id,
                        "sender_id": m.sender_id,
                        "sender_role": m.sender_role,
                        "sender_name": m.sender_name,
                        "content": m.content,
                        "timestamp": m.timestamp.isoformat(),
                    }
                    for m in messages
                ]
            }
        )

    @guardian_api.route("/<int:guardian_id>/senior/<int:senior_id>/messages/send", methods=["POST"])
    def send_message_to_senior(guardian_id, senior_id):
        senior = db_session.query(Senior).filter_by(id=senior_id, guardian_id=guardian_id).first()
        if not senior:
            return jsonify({"error": "Invalid senior selected"}), 400

        data = request.get_json() or {}
        content = (data.get("content") or "").strip()
        if not content:
            return jsonify({"error": "Message content required"}), 400

        g = db_session.query(Guardian).get(guardian_id)
        message = Message(
            senior_id=senior_id,
            sender_role="guardian",
            sender_id=guardian_id,
            sender_name=g.name if g else "Guardian",
            content=content,
            timestamp=datetime.utcnow(),
        )
        db_session.add(message)
        db_session.commit()

        return jsonify(
            {
                "id": message.id,
                "senior_id": senior_id,
                "sender_id": guardian_id,
                "sender_role": message.sender_role,
                "sender_name": message.sender_name,
                "content": content,
                "timestamp": message.timestamp.isoformat(),
            }
        )

    # -------------------- AUDIO --------------------
    @guardian_api.route("/<int:guardian_id>/audios", methods=["GET"])
    def get_audios(guardian_id):
        audios = (
            db_session.query(Audio)
            .join(Senior)
            .filter(Senior.guardian_id == guardian_id)
            .all()
        )
        return jsonify({
            "audios": [
                {
                    "id": a.id,
                    "title": a.title,
                    "filename": a.filename,
                    "senior_id": a.senior_id,
                    "uploaded_at": a.uploaded_at.isoformat(),
                }
                for a in audios
            ]
        })

    @guardian_api.route("/<int:guardian_id>/upload-audio", methods=["POST"])
    def upload_audio(guardian_id):
        if "file" not in request.files:
            return jsonify({"error": "No file uploaded"}), 400

        file = request.files["file"]
        if file.filename == "":
            return jsonify({"error": "Empty filename"}), 400
        if not _allowed_file(file.filename):
            return jsonify({"error": "Invalid file type"}), 400

        # Parse form data
        try:
            senior_ids = json.loads(request.form.get("senior_ids", "[]"))
        except Exception:
            return jsonify({"error": "Invalid senior_ids"}), 400

        title = (request.form.get("title") or "").strip()
        if not senior_ids or not title:
            return jsonify({"error": "Missing title or seniors"}), 400

        # Verify seniors belong to this guardian
        seniors = (
            db_session.query(Senior)
            .filter(Senior.id.in_(senior_ids), Senior.guardian_id == guardian_id)
            .all()
        )
        if len(seniors) != len(senior_ids):
            return jsonify({"error": "Invalid senior(s)"}), 400

        # Save file once
        original_name = secure_filename(file.filename)
        unique_name = _unique_filename(original_name, title=title)
        filepath = os.path.join(UPLOAD_FOLDER, unique_name)
        file.save(filepath)

        # Create DB records
        new_audios = []
        for s in seniors:
            audio = Audio(
                senior_id=s.id,
                title=title,
                filename=unique_name,
                uploaded_at=datetime.utcnow(),
            )
            db_session.add(audio)
            new_audios.append(audio)

        db_session.commit()

        return jsonify({
            "success": True,
            "audios": [
                {
                    "id": a.id,
                    "title": a.title,
                    "filename": a.filename,
                    "senior_id": a.senior_id,
                    "uploaded_at": a.uploaded_at.isoformat(),
                }
                for a in new_audios
            ]
        })

    @guardian_api.route("/<int:guardian_id>/audios/<int:audio_id>", methods=["DELETE"])
    def delete_audio(guardian_id, audio_id):
        audio = (
            db_session.query(Audio)
            .join(Senior)
            .filter(Audio.id == audio_id, Senior.guardian_id == guardian_id)
            .first()
        )
        if not audio:
            return jsonify({"error": "Audio not found"}), 404

        file_path = os.path.join(UPLOAD_FOLDER, audio.filename)
        # Check if other records reference this file
        others = (
            db_session.query(Audio)
            .filter(Audio.filename == audio.filename, Audio.id != audio.id)
            .count()
        )

        db_session.delete(audio)
        db_session.commit()

        if others == 0 and os.path.exists(file_path):
            os.remove(file_path)

        return jsonify({"success": True})

    @guardian_api.route("/<int:guardian_id>/audios/<int:audio_id>", methods=["PUT", "PATCH"])
    def update_audio(guardian_id, audio_id):
        data = request.get_json() or {}
        new_title = (data.get("title") or "").strip()

        audio = (
            db_session.query(Audio)
            .join(Senior)
            .filter(Audio.id == audio_id, Senior.guardian_id == guardian_id)
            .first()
        )
        if not audio:
            return jsonify({"error": "Audio not found"}), 404

        if new_title:
            audio.title = new_title
            db_session.commit()

        return jsonify({
            "id": audio.id,
            "title": audio.title,
            "filename": audio.filename,
            "senior_id": audio.senior_id,
            "uploaded_at": audio.uploaded_at.isoformat(),
        })

    # -------------------- STREAM AUDIO --------------------
    @guardian_api.route("/<int:guardian_id>/audios/<int:audio_id>/stream", methods=["GET"])
    def stream_audio(guardian_id, audio_id):
        """Stream audio for playback in <audio> tag"""
        audio = (
            db_session.query(Audio)
            .join(Senior)
            .filter(Audio.id == audio_id, Senior.guardian_id == guardian_id)
            .first()
        )
        if not audio:
            return jsonify({"error": "Not found"}), 404

        file_path = os.path.join(UPLOAD_FOLDER, audio.filename)
        if not os.path.exists(file_path):
            return jsonify({"error": "File missing"}), 404

        # Handle partial content (for scrubbing in <audio>)
        file_size = os.path.getsize(file_path)
        range_header = request.headers.get("Range", None)
        mime = mimetypes.guess_type(file_path)[0] or "application/octet-stream"

        if not range_header:
            return send_file(file_path, mimetype=mime, as_attachment=False)

        # Parse Range header
        match = re.match(r"bytes=(\d*)-(\d*)", range_header)
        if not match:
            return abort(416)

        start_str, end_str = match.groups()
        try:
            start = int(start_str) if start_str else 0
            end = int(end_str) if end_str else file_size - 1
        except ValueError:
            return abort(416)

        if start > end or end >= file_size:
            return abort(416)

        length = (end - start) + 1
        with open(file_path, "rb") as f:
            f.seek(start)
            data = f.read(length)

        rv = Response(data, 206, mimetype=mime, direct_passthrough=True)
        rv.headers.add("Content-Range", f"bytes {start}-{end}/{file_size}")
        rv.headers.add("Accept-Ranges", "bytes")
        rv.headers.add("Content-Length", str(length))
        return rv

    # -------------------- DOWNLOAD AUDIO --------------------
    @guardian_api.route("/<int:guardian_id>/audios/<int:audio_id>/download", methods=["GET"])
    def download_audio(guardian_id, audio_id):
        """Force download of audio file with proper title.mp3 filename"""
        audio = (
            db_session.query(Audio)
            .join(Senior)
            .filter(Audio.id == audio_id, Senior.guardian_id == guardian_id)
            .first()
        )
        if not audio:
            return jsonify({"error": "Not found"}), 404

        file_path = os.path.join(UPLOAD_FOLDER, audio.filename)
        if not os.path.exists(file_path):
            return jsonify({"error": "File missing"}), 404

        return send_file(
            file_path,
            mimetype=mimetypes.guess_type(file_path)[0] or "application/octet-stream",
            as_attachment=True,
            download_name=f"{_slugify(audio.title)}.mp3"
        )
    # -------------------- APPOINTMENTS --------------------
    @guardian_api.route("/<int:guardian_id>/senior/<int:senior_id>/appointments", methods=["GET"])
    def get_appointments(guardian_id, senior_id):
        senior = db_session.query(Senior).filter_by(id=senior_id, guardian_id=guardian_id).first()
        if not senior:
            return jsonify({"error": "Invalid senior selected"}), 400

        appointments = (
            db_session.query(Appointment)
            .filter_by(senior_id=senior_id, guardian_id=guardian_id)
            .all()
        )

        return jsonify({
            "senior": {
                "id": senior.id,
                "name": senior.name,
                "phone": senior.phone
            },
            "appointments": [
                {
                    "id": a.id,
                    "senior_id": a.senior_id,
                    "guardian_id": a.guardian_id,
                    "details": a.details,
                    "date": a.date.isoformat() if a.date else None,
                    "is_completed": a.is_completed
                }
                for a in appointments
            ]
        })



    @guardian_api.route("/<int:guardian_id>/senior/<int:senior_id>/add_appointment", methods=["POST"])
    def add_appointment(guardian_id, senior_id):
        senior = db_session.query(Senior).filter_by(id=senior_id, guardian_id=guardian_id).first()
        if not senior:
            return jsonify({"error": "Invalid senior selected"}), 400

        data = request.get_json() or {}
        details = data.get("details")
        date_str = data.get("date")
        is_completed = data.get("is_completed", False)  # get from request, default False

        if not details or not date_str:
            return jsonify({"error": "Missing details or date"}), 400

        try:
            dt = datetime.fromisoformat(date_str)  # expects "YYYY-MM-DDTHH:MM:SS"
        except Exception:
            return jsonify({"error": "Invalid date format"}), 400

        appointment = Appointment(
            senior_id=senior_id,
            guardian_id=guardian_id,
            details=details,
            date=dt,
            is_completed=is_completed
        )

        db_session.add(appointment)
        db_session.commit()

        return jsonify({"success": True, "appointment_id": appointment.id})


    @guardian_api.route("/<int:guardian_id>/appointment/<int:appointment_id>", methods=["PUT"])
    def update_appointment(guardian_id, appointment_id):
        appointment = (
            db_session.query(Appointment)
            .filter_by(id=appointment_id, guardian_id=guardian_id)
            .first()
        )
        if not appointment:
            return jsonify({"error": "Appointment not found"}), 404

        data = request.get_json() or {}
        if "details" in data:
            appointment.details = data["details"]

        if "date" in data:
            try:
                appointment.date = datetime.fromisoformat(data["date"])
            except Exception:
                return jsonify({"error": "Invalid date format"}), 400

        if "is_completed" in data:
            appointment.is_completed = bool(data["is_completed"])  # update completion status

        db_session.commit()
        return jsonify({"success": True})


    @guardian_api.route("/<int:guardian_id>/appointment/<int:appointment_id>", methods=["DELETE"])
    def delete_appointment(guardian_id, appointment_id):
        appointment = (
            db_session.query(Appointment)
            .filter_by(id=appointment_id, guardian_id=guardian_id)
            .first()
        )
        if not appointment:
            return jsonify({"error": "Appointment not found"}), 404

        db_session.delete(appointment)
        db_session.commit()

        return jsonify({"success": True})



    return guardian_api
