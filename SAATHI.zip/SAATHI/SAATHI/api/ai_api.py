# api/ai_api.py
from flask import Blueprint, request, jsonify
from models import db_session as global_db_session

from datetime import datetime
import operator
import tempfile
import logging
import shutil
import os
from flask import Flask, request, jsonify, Response
from werkzeug.utils import secure_filename

# LangChain/LangGraph imports
from langchain_core.messages import BaseMessage, HumanMessage, AIMessage, ToolMessage
from langchain_core.prompts import ChatPromptTemplate, MessagesPlaceholder
from langchain_core.tools import tool, Tool
from langgraph.graph import StateGraph, END
from langchain_groq import ChatGroq

# Api lib
from typing import TypedDict, Annotated, Sequence, Optional, List
from pydantic import BaseModel, Field
from groq import Groq, APIError
import dateparser
from models import Reminder, ReminderLog, db_session

#==========================Ai APIS============================
os.environ["GROQ_API_KEY"] = "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"
# It's better to load this from a config or environment variable when deploying.

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

# --- Groq Client and LLM Setup ---
try:
    groq_client = Groq()
    llm = ChatGroq(model="llama3-8b-8192", temperature=0) # Using Llama 3 8B model
except Exception as e:
    logger.error(f"Failed to initialize Groq client or LLM: {e}")
    # In a real Flask app, you might want to handle this more gracefully,
    # perhaps by disabling features or returning an error response.
    groq_client = None
    llm = None


def create_ai_interaction(db_session):
    global global_db_session
    global_db_session = db_session

    ai_api = Blueprint('ai_api', __name__)

    # --- Audio Transcription ---

    def extract_text_from_audio(audio_file_content: bytes, filename: str) -> str:
        """
        Transcribes audio content using Groq's Whisper model.
        Args:
            audio_file_content: The binary content of the audio file.
            filename: The original filename of the audio file.
        Returns:
            The transcribed text.
        Raises:
            RuntimeError: If transcription fails.
        """
        if not groq_client:
            raise RuntimeError("Groq client is not initialized.")

        logger.info(f"Passing audio content to Groq Whisper model for file: {filename}")
        try:
            # Groq's create method expects a tuple: (filename, file_object) or (filename, file_content_bytes)
            transcription = groq_client.audio.transcriptions.create(
                file=(filename, audio_file_content),
                model="whisper-large-v3",
                response_format="verbose_json",
            ).text.strip()

            logger.info("Text extracted successfully.")
            return transcription
        except APIError as e:
            logger.error(f"Groq API Error during transcription: Status {e.response.status_code}, Detail: {e.response.text}")
            raise RuntimeError(f"Groq API transcription failed: {e.response.text if e.response else str(e)}")
        except Exception as e:
            logger.exception("An unexpected error occurred during audio transcription.")
            raise RuntimeError(f"An internal error occurred during transcription: {str(e)}")

    @ai_api.route("/health", methods=["GET"])
    def health_check():
        """
        Checks the health of the application.
        """
        # You could add checks for groq_client initialization here if needed
        return jsonify({"status": "healthy"})

    @ai_api.route("/transcribe-audio", methods=["POST"])
    def transcribe_audio():
        """
        Handles audio file uploads for transcription.
        Expects a multipart/form-data request with an 'audio_file' field.
        """
        print("***************")
        print(request.files)
        print("***************")
        if 'audio_file' not in request.files:
            return jsonify({"error": "No audio file part in the request."}), 400
        
        audio_file = request.files['audio_file']

        if audio_file.filename == '':
            return jsonify({"error": "No selected file."}), 400

        if not audio_file:
            return jsonify({"error": "Invalid file uploaded."}), 400

        temp_audio_path = None
        try:
            # Use secure_filename for safety
            filename = secure_filename(audio_file.filename)
            if not filename:
                return jsonify({"error": "Invalid filename."}), 400

            # Read the file content directly
            audio_content = audio_file.read()

            # Transcribe the audio using the helper function
            transcribed_text = extract_text_from_audio(audio_content, filename)

            return jsonify({"transcribed_text": transcribed_text}), 200

        except RuntimeError as e:
            logger.error(f"Transcription failed: {e}")
            return jsonify({"error": str(e)}), 500
        except Exception as e:
            logger.exception("An unexpected error occurred in /transcribe-audio endpoint.")
            return jsonify({"error": f"An internal server error occurred: {str(e)}"}), 500

    # --- LLM Powered Reminder ---

    class AddReminderInput(BaseModel):
        reason: str
        date: str
        time: Optional[str] = None

        # This is for Pydantic validation, which Flask's jsonify won't directly use for request parsing.
        # For request body parsing, we'll handle it manually or use a library like Flask-RESTful/Flask-Smorest.
        # For simplicity, we'll parse JSON directly from request.get_json().

    def add_reminder(reason: str, time: Optional[str] = None, senior_id: Optional[int] = 1) -> str:
        """
        Adds a new reminder for a senior into the database.
        
        Args:
            reason (str): The reminder reason (e.g., medicine name).
            time (str, optional): Natural language time (e.g., '3pm', 'noon').
            senior_id (int, optional): ID of the senior. Defaults to 1 (for now).
        """

        try:

            # Parse the time if provided
            parsed_time = None
            if time:
                parsed_time = dateparser.parse(time)
                if not parsed_time:
                    return f"Could not understand the time: '{time}'"

            # Extract final datetime values
            reminder_time = parsed_time.time() if parsed_time else datetime.now().time()

            # Insert reminder into DB
            new_reminder = Reminder(
                senior_id=senior_id,
                medicine_name=reason,
                reminder_time=reminder_time,
                is_completed=False
            )
            db_session.add(new_reminder)
            db_session.commit()

            return f"✅ Reminder '{reason}' set successfully for {reminder_time.strftime('%H:%M')}"

        except Exception as e:
            db_session.rollback()
            return f"❌ Failed to set reminder: {str(e)}"

    # --- LangGraph Agent Setup ---

    # Declaring list of tools
    # In Flask, tools are just Python functions. LangGraph will handle mapping them.
    tools_for_graph = [
        Tool(
            name="add_reminder",
            func=add_reminder,
            description="Adds a reminder with a reason, and optional time. Use this to set reminders for the user."
        )
    ]

    # Bind tools to the LLM
    if llm:
        llm_with_tools = llm.bind_tools(tools_for_graph)
    else:
        llm_with_tools = None # Handle case where LLM initialization failed

    # Define Agent state
    class AgentState(TypedDict):
        messages: Annotated[Sequence[BaseMessage], operator.add]
        tool_calls: Optional[List[dict]]
        tool_response: Optional[str]
        agent_outcome: Optional[AIMessage]

    # Define the chat prompt
    system_message = """You are a helpful and efficient AI assistant specializing in managing reminders.
    Your primary goal is to determine if the user's request is to set a reminder.

    If the user wants to set a reminder:
    - Use the 'add_reminder' tool.
    - Extract the 'reason', 'date', and optionally 'time' from the user's input.
    - Be intelligent about parsing natural language dates and times (e.g., 'tomorrow', 'next week', '3 PM', 'noon', 'end of day').
    - If a specific time is not mentioned, you should try to infer it if contextually relevant (e.g., 'morning' -> '9 AM') or leave it as None if no time context is provided.
    - If any crucial information (like the reason or a clear date) is missing for a reminder, you MUST ask clarifying questions before attempting to call the tool. For example, if they say 'Remind me to do something', ask 'What should I remind you to do and when?'.

    If the user's request is NOT about setting a reminder (e.g., general questions, greetings):
    - Respond directly and helpfully to their query without attempting to use any tools.

    Be concise and get straight to the point.
    """
    prompt = ChatPromptTemplate.from_messages([
        ("system", system_message),
        MessagesPlaceholder(variable_name="messages"),
    ])

    # Chain the prompt with the LLM
    if llm_with_tools:
        agent_runnable = prompt | llm_with_tools
    else:
        agent_runnable = None # Handle case where LLM initialization failed

    # Node to call the LLM
    def call_llm_node(state: AgentState):
        """
        Invokes the LLM with the current conversation history and updates the state.
        """
        if not agent_runnable:
            raise RuntimeError("LLM is not available.")

        messages = state["messages"]
        response = agent_runnable.invoke({"messages": messages})
        logger.debug(f"LLM Response: {response}")
        return {"messages": [response], "tool_calls": response.tool_calls, "agent_outcome": response}

    # Node to call the tool
    def call_tool_node(state: AgentState):
        """
        Executes the tool chosen by the LLM and updates the state.
        """
        if not state["tool_calls"]:
            return {"messages": [], "tool_response": "No tool calls found."} # Should not happen if logic is correct

        tool_call = state["tool_calls"][0] # Assuming one tool call for simplicity
        tool_name = tool_call["name"]
        tool_args = tool_call["args"]
        tool_id = tool_call["id"]

        logger.debug(f"Calling tool: {tool_name} with args: {tool_args}")

        tool_response_content = ""
        if tool_name == "add_reminder":
            # The add_reminder function is already defined and handles parsing
            tool_response_content = add_reminder(
                reason=tool_args.get('reason', ''),
                time=tool_args.get('time')
            )
        else:
            tool_response_content = f"Unknown tool: {tool_name}"
            logger.warning(f"Attempted to call unknown tool: {tool_name}")

        logger.debug(f"Tool response: {tool_response_content}")

        return {
            "messages": [
                ToolMessage(
                    content=tool_response_content,
                    tool_call_id=tool_id
                )
            ],
            "tool_response": tool_response_content # Also store in tool_response field for potential further processing
        }

    def should_continue_node(state: AgentState) -> str:
        """
        Determines whether the graph should continue to the tool node or end.
        """
        if state["tool_calls"]:
            logger.debug("LLM wants to call a tool.")
            return "call_tool_node" # Go to tool node if LLM wants to call a tool
        else:
            logger.debug("LLM provided a direct response.")
            return "end_graph" # End the graph if LLM provides a direct answer (no tool call)

    # Flow
    workflow = StateGraph(AgentState)
    workflow.add_node("call_llm_node", call_llm_node)
    workflow.add_node("call_tool_node", call_tool_node)

    workflow.set_entry_point("call_llm_node")

    workflow.add_conditional_edges(
        "call_llm_node",
        should_continue_node,
        {
            "call_tool_node": "call_tool_node",
            "end_graph": END
        }
    )

    workflow.add_edge("call_tool_node", END) # After tool execution, always end the graph for this simplified flow
    agent_app = workflow.compile()

    # --- Chat Endpoint ---

    class UserInput(BaseModel):
        text: str

    class AIResponse(BaseModel):
        response: str
        reminders_list: Optional[List[dict]] = None # Keep for consistency, though not actively used in this Flask version

    @ai_api.route("/chat/", methods=["POST"])
    def chat_with_agent():
        """
        Sends a user query to the AI agent and receives a response.
        The agent will either set a reminder or respond directly.
        Expects JSON payload with a 'text' field.
        """
        if not agent_app:
            return jsonify({"response": "Error: AI agent not available."}), 500

        if not request.is_json:
            return jsonify({"error": "Request must be JSON"}), 400

        user_input_data = request.get_json()
        try:
            user_input = UserInput(**user_input_data)
        except ValueError as e:
            return jsonify({"error": f"Invalid input format: {str(e)}"}), 400

        try:
            # Initial state setup: we start with the user's message
            initial_state = {"messages": [HumanMessage(content=user_input.text)]}

            result = agent_app.invoke(initial_state, {"recursion_limit": 50})

            # Determine the final message to return
            final_response_content = ""
            if result and result.get("messages"):

                last_message = result["messages"][-1]
                if isinstance(last_message, ToolMessage):
                    # If the last message is from a tool, its content is the tool's output.
                    final_response_content = f"Reminder operation result: {last_message.content}"
                elif isinstance(last_message, AIMessage):
                    # If it's a direct AI message, use its content.
                    final_response_content = last_message.content
                else:
                    # Fallback for other message types or if content is not directly accessible.
                    final_response_content = str(last_message)
            else:
                final_response_content = "An unexpected error occurred or no response was generated."

            return jsonify({"response": final_response_content}), 200

        except Exception as e:
            logger.exception("Error during agent invocation in /chat/")
            return jsonify({"response": f"An error occurred: {str(e)}"}), 500

    return ai_api