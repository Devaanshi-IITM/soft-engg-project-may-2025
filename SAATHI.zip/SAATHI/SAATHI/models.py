from sqlalchemy import Column, Integer, String, Boolean, ForeignKey, DateTime, Time, Text
from sqlalchemy.ext.declarative import declarative_base
from sqlalchemy.orm import relationship
from datetime import datetime

Base = declarative_base()
db_session = None  # Will be injected from app.py

class Guardian(Base):
    __tablename__ = 'guardians'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    phone = Column(String, unique=True)
    password = Column(String)

    # One guardian can manage many seniors
    seniors = relationship("Senior", backref="guardian", cascade="all, delete-orphan")


class Senior(Base):
    __tablename__ = 'seniors'
    id = Column(Integer, primary_key=True)
    name = Column(String)
    phone = Column(String, unique=True)
    guardian_id = Column(Integer, ForeignKey('guardians.id'))


class Message(Base):
    __tablename__ = 'messages'
    id = Column(Integer, primary_key=True)
    senior_id = Column(Integer, ForeignKey('seniors.id'))
    sender_role = Column(String)      # 'guardian' or 'senior'
    sender_id = Column(Integer)       # ID of sender
    sender_name = Column(String)      # Optional: stored name of sender
    content = Column(Text)
    timestamp = Column(DateTime, default=datetime.utcnow)


class Reminder(Base):
    __tablename__ = 'reminders'
    id = Column(Integer, primary_key=True)
    senior_id = Column(Integer, ForeignKey('seniors.id'))
    medicine_name = Column(String)
    reminder_time = Column(Time)               #
    is_completed = Column(Boolean, default=False)


class ReminderLog(Base):
    __tablename__ = 'reminder_logs'
    id = Column(Integer, primary_key=True)
    reminder_id = Column(Integer, ForeignKey('reminders.id'))
    completed_by = Column(String)             
    timestamp = Column(DateTime, default=datetime.utcnow)


class Audio(Base):
    __tablename__ = 'audio'
    id = Column(Integer, primary_key=True)
    senior_id = Column(Integer, ForeignKey('seniors.id'))  # ADD THIS
    title = Column(String)
    filename = Column(String) 
    uploaded_at = Column(DateTime, default=datetime.utcnow)


class Update(Base):
    __tablename__ = 'updates'
    id = Column(Integer, primary_key=True)
    title = Column(String)
    content = Column(Text)


class Appointment(Base):
    __tablename__ = 'appointments'
    id = Column(Integer, primary_key=True)
    senior_id = Column(Integer, ForeignKey('seniors.id'))
    guardian_id = Column(Integer, ForeignKey('guardians.id')) 
    date = Column(DateTime)
    details = Column(Text)
    is_completed = Column(Boolean, default=False) 
