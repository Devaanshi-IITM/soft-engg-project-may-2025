from flask import Flask, send_from_directory
from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from models import Base
import models
from api import register_blueprints
import os

app = Flask(__name__, static_folder='static', static_url_path='')

# DB Setup
engine = create_engine('sqlite:///database.db', connect_args={'check_same_thread': False})
Base.metadata.create_all(engine)
Session = sessionmaker(bind=engine)
db_session = Session()

# Inject db_session if still using in models
models.db_session = db_session

# Register blueprints with session
register_blueprints(app, db_session)

@app.route('/', defaults={'path': ''})
@app.route('/<path:path>')
def serve_vue(path):
    file_path = os.path.join(app.static_folder, path)

    # If path exists in static folder, serve it
    if path != "" and os.path.exists(file_path):
        return send_from_directory(app.static_folder, path)

    # Otherwise, serve index.html so Vue Router can handle the route
    return send_from_directory(app.static_folder, 'index.html')

if __name__ == '__main__':
    app.run(debug=True)